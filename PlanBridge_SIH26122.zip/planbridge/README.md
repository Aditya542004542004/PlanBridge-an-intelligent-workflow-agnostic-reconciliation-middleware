# PlanBridge

**"From Field Reality to Schedule Truth"**

A working prototype built for **Smart India Hackathon – SIH26122 – Oil India Limited (OIL)**.

PlanBridge connects unstructured field execution reports (DPRs, PDFs, Excel
sheets, site diaries, text messages, voice notes) to structured
Primavera-style project activities, using a hybrid entity + semantic
matching engine with an explainable, confidence-gated safety model.

> **This is a hackathon prototype.** It does not connect to any live OIL
> system, live Primavera P6 instance, or real confidential OIL data. See
> [Limitations](#limitations) for the full honesty statement.

---

## 1. Problem Statement

OIL infrastructure projects run two disconnected worlds:

- **Planning world:** Primavera P6 / MS Project — WBS, Activity IDs, planned
  dates, planned quantities.
- **Execution world:** DPRs, PDFs, Excel files, site diaries, texts, emails,
  voice reports, scanned documents.

A planner has to manually read "150m HDD drilling completed today near KP
24+600 at river site" and figure out which of possibly 50,000+ Primavera
activities that maps to, whether the quantity is consistent, and whether it's
safe to auto-update the schedule. PlanBridge automates that pipeline while
keeping a human in the loop wherever confidence is not high enough.

## 2. Architecture

```
Field Report (PDF/Excel/CSV/TXT/voice/manual)
        │
        ▼
 Ingestion & Hashing (SHA-256, duplicate detection)
        │
        ▼
 Entity Extraction (regex: KP, line, location, activity type, quantity, unit)
        │
        ▼
 Deterministic Unit Normalization (pure arithmetic, never LLM-guessed)
        │
        ▼
 Stage 1: Entity-based Candidate Filtering (indexed KP/type/location lookup)
        │
        ▼
 Stage 2: Semantic Ranking (sentence-transformers, TF-IDF fallback)
        │
        ▼
 Confidence Engine (45% semantic + 35% entity + 20% quantity)
        │
        ├── > 85%   → AUTO-LINK
        ├── 60–85%  → PLANNER REVIEW QUEUE
        └── < 60%   → UNMATCHED QUEUE
        │
        ▼
 Dual Progress Model (Physical % / QA-Verified %, never merged)
        │
        ▼
 Evidence Record (SHA-256 tamper-detection fingerprint) + Audit Trail
        │
        ▼
 Planner Approval → Prototype P6-Compatible Export (CSV / XML)
```

## 3. Features

| Area | What's implemented |
|---|---|
| Multi-format ingestion | PDF (PyMuPDF), Excel, CSV, TXT, manual text, voice (simulated transcription) |
| Entity extraction | Regex-based KP/line/location/activity-type/quantity/unit/contractor/equipment extraction |
| Unit normalization | Deterministic length & mass conversion table; unknown units routed to planner, never guessed |
| Hybrid matching | Entity filtering (stage 1) → semantic ranking (stage 2) |
| Confidence engine | Configurable weighted score + 3-tier decision gate |
| Explainable AI | Every match shows a per-criterion breakdown, not just a number |
| Dual progress model | Physical progress vs QA-Verified progress, tracked and displayed separately |
| QA/QC | PENDING/PASSED/FAILED gate that unlocks verified progress |
| Evidence & audit | SHA-256 fingerprinted evidence records + a full audit log of every action |
| Planner review | Approve / Reject / Reassign / Send-to-Unmatched workflow |
| P6 export | CSV and XML prototype export packages, planner-approved before generation |
| RBAC | ADMIN / PLANNER / FIELD_ENGINEER / QA_ENGINEER / PROJECT_MANAGER |
| Evaluation | Synthetic benchmark comparing Keyword vs Semantic vs Hybrid matching |
| Demo Mode | Guided 11-step walkthrough on the dashboard |

## 4. Tech Stack

- **Frontend:** React + TypeScript + Vite, Tailwind CSS, Lucide React icons, Recharts
- **Backend:** Python, FastAPI, Pydantic, SQLAlchemy
- **Database:** SQLite for the local demo — the SQLAlchemy layer is
  provider-agnostic, so switching to PostgreSQL is a one-line `DATABASE_URL`
  change, no query code changes required
- **AI:** sentence-transformers (`all-MiniLM-L6-v2`) with an automatic,
  deterministic TF-IDF/hashing fallback if the model can't be downloaded —
  **the matching demo never breaks due to a missing external model or API**
- **Document processing:** PyMuPDF, pandas, openpyxl
- **Auth:** JWT (python-jose) + bcrypt (passlib)
- **Export:** CSV, XML (clearly labelled as a *prototype P6-compatible
  export representation*, not a real .XER / live Primavera connection)

## 5. Folder Structure

```
planbridge/
├── backend/
│   ├── app/
│   │   ├── main.py                # FastAPI app, router registration
│   │   ├── core/                  # config, database, security (JWT/RBAC)
│   │   ├── models/                # SQLAlchemy models (15 tables)
│   │   ├── schemas/                # Pydantic request/response schemas
│   │   ├── api/                    # auth, reports, matching, activities, qa, misc, evaluation
│   │   ├── services/                # evidence, progress (dual model)
│   │   ├── ai/                      # embedder (sentence-transformers + fallback)
│   │   ├── matching/                # candidate filtering, confidence engine
│   │   ├── ingestion/                # PDF/Excel/CSV/TXT/voice parsers
│   │   ├── normalization/            # entity extraction, unit normalizer
│   │   ├── audit/                    # audit trail logger
│   │   ├── export/                   # CSV/XML exporter
│   │   └── seed/                     # deterministic demo data
│   ├── tests/                        # pytest suite
│   ├── requirements.txt
│   ├── .env.example
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── components/               # Sidebar, Header, StatCard, ActivityTable, ...
│   │   ├── pages/                    # Login, Dashboard, Projects, Activities, ...
│   │   ├── api/client.ts             # typed fetch wrapper
│   │   └── types/
│   ├── package.json
│   ├── Dockerfile
│   └── nginx.conf
├── docker-compose.yml
└── README.md
```

## 6. Installation & Running Locally

### Option A — Docker (recommended)

```bash
docker compose up
```

- Backend: http://localhost:8000 (docs at `/docs`)
- Frontend: http://localhost:8080

The backend container seeds the deterministic demo dataset automatically on
first start.

### Option B — Without Docker

**Backend:**
```bash
cd backend
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python -m app.seed.seed_data          # seeds demo project, activities, reports
uvicorn app.main:app --reload --port 8000
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```
Visit http://localhost:5173.

> If `sentence-transformers` can't download its model weights (no internet
> at hackathon venue, etc.), PlanBridge automatically falls back to a
> deterministic TF-IDF-style similarity engine — no code changes needed, the
> demo still runs end-to-end.

## 7. Demo Credentials

| Role | Email | Password |
|---|---|---|
| Admin | admin@planbridge.demo | `PlanBridge@2026` |
| Planner | planner@planbridge.demo | `PlanBridge@2026` |
| QA Engineer | qa@planbridge.demo | `PlanBridge@2026` |
| Project Manager | manager@planbridge.demo | `PlanBridge@2026` |
| Field Engineer | field@planbridge.demo | `PlanBridge@2026` |

These are demo-only accounts seeded locally — not real OIL credentials.

## 8. Demo Workflow (Golden Demo)

1. Log in as `field@planbridge.demo`.
2. **Field Reports** → submit: `150m HDD drilling completed today near KP 24+600 at river site.`
3. **Report Processing** → extract entities: KP `24+600`, Activity `HDD`, Quantity `150 m`, Location `river site`.
4. **Matching Engine** → run matching → top candidate `PIP-L5-024-003` at ~90%+ confidence → **AUTO-LINK**.
5. **Activities → PIP-L5-024-003** → Physical Progress `30%`, Verified Progress `0%` (QA pending).
6. Log in as `qa@planbridge.demo` → **Field Reports** → submit: `NDT radiography passed for 150m HDD at KP 24+600.` → process → match (or open **QA/QC** directly and log a PASSED NDT Radiography record against `PIP-L5-024-003`).
7. Verified Progress updates to `30%` (now equal to Physical Progress).
8. Open the activity's **Evidence & Audit** timeline — SHA-256 fingerprints and the full event trail are visible.
9. Log in as `planner@planbridge.demo` → **P6 Export** → select `PIP-L5-024-003` → generate a CSV/XML export package.
10. Or just click **DEMO MODE** on the Dashboard for the guided 11-step walkthrough.

## 9. API Documentation

Interactive OpenAPI docs are auto-generated at `http://localhost:8000/docs`
once the backend is running. Key endpoints:

```
POST  /auth/login

POST  /reports/upload            POST /reports/text
GET   /reports                   GET  /reports/{id}
POST  /reports/{id}/process

POST  /matching/run/{report_id}  GET  /matching/{report_id}
GET   /review-queue
POST  /matches/{id}/approve      POST /matches/{id}/reject

GET   /activities                GET  /activities/{id}
POST  /qa                        GET  /qa
GET   /progress/{activity_id}
GET   /evidence/{activity_id}
GET   /audit

POST  /exports                   GET  /exports/{id}
GET   /evaluation/run?project_id=1

GET   /dashboard
GET   /health
```

## 10. AI Architecture

- **Entity extraction** is pure regex, not an LLM call — deterministic and
  testable (`app/normalization/entities.py`).
- **Unit normalization** is a fixed conversion table — never delegated to a
  model (`app/normalization/units.py`). Unrecognised/domain-specific units
  (e.g. "spools") are never guessed; they're flagged `UNKNOWN_UNIT` and
  routed to planner review.
- **Semantic similarity** tries `sentence-transformers` first; if the
  package or model weights are unavailable it automatically falls back to a
  deterministic hashing/TF-IDF-style vector model built on scikit-learn/numpy
  primitives (`app/ai/embedder.py`). The rest of the system is agnostic to
  which backend is active.
- **Candidate filtering** never runs semantic inference against a full
  50,000-row activities table — it first narrows to a handful of candidates
  via indexed KP/activity-type/location lookups (`app/matching/candidates.py`),
  which is what actually makes the architecture scale, not the size of the
  demo dataset.
- **Confidence scoring** is a transparent weighted sum
  (45% semantic + 35% entity + 20% quantity, configurable in
  `app/core/config.py`) with a full explanation object returned alongside
  every score — never a bare percentage.

## 11. Database

15 tables: `users`, `roles`, `projects`, `contractors`, `wbs_nodes`,
`activities`, `field_reports`, `report_entities`, `activity_matches`,
`progress_records`, `qa_records`, `evidence_records`, `planner_reviews`,
`export_packages`, `audit_logs`. See `backend/app/models/models.py`.

Indexes are placed on `project_id`, `activity_id`, `kp`, `location_tag`, and
`status` columns to keep candidate filtering fast as the activities table
grows.

SQLite is used for the local demo; switching `DATABASE_URL` to a
`postgresql+psycopg2://...` URL is the only change needed to move to
PostgreSQL — no model or query code depends on SQLite specifically.

## 12. Testing

```bash
cd backend
pytest -v
```

Covers: KP extraction, unit conversion (incl. unknown units), entity
extraction edge cases, candidate filtering, the golden-demo matching
scenario, confidence gate thresholds, duplicate detection, physical/verified
progress calculation, QA pass/fail gating, evidence SHA-256 fingerprints,
CSV/XML export content, RBAC role enforcement, and full HTTP-level API tests
for the golden demo flow.

> **Sandbox note:** the assistant that generated this repository verified
> the core deterministic logic (unit normalization, entity extraction,
> semantic similarity ordering, and the full confidence-scoring pipeline —
> including reproducing the exact golden-demo AUTO-LINK decision) directly,
> because the code-execution sandbox used to build this project has no
> package-registry access and could not install FastAPI/SQLAlchemy/npm
> packages to run the full server. On a normal machine with internet access,
> `pip install -r requirements.txt && pytest -v` runs the complete suite
> above, including the FastAPI `TestClient` end-to-end tests.

## 13. Evaluation

The **Evaluation** page (`/evaluation`) runs a synthetic benchmark comparing
Keyword Matching, Semantic-only Matching, and Hybrid PlanBridge matching
against the seeded demo reports, reporting Top-1/Top-3 accuracy, precision,
recall, F1, false auto-accept rate, and average processing time. Results are
always labelled **"Synthetic Prototype Evaluation"** — this is not a
real-world accuracy measurement.

## 14. Security

- JWT authentication, bcrypt password hashing, RBAC on all mutating endpoints
- File type and file size validation on uploads (`MAX_UPLOAD_MB`)
- CORS restricted to configured origins
- No hardcoded secrets — all configuration via environment variables /
  `.env` (`.env.example` provided)
- SQL injection protection via SQLAlchemy's parameterized queries (no raw
  string-built SQL anywhere in the codebase)

## 15. Limitations

PlanBridge is a hackathon prototype. It explicitly does **not** claim:

- A live connection to any OIL database or OIL API
- A live Primavera P6 connection or a real `.XER` file (exports are a
  clearly labelled *prototype P6-compatible representation*)
- Real confidential OIL project data (all seed data is synthetic)
- CVC/CAG certification or production cybersecurity approval
- A measured 95%/99%+ accuracy figure without running the evaluation page
  yourself against your own data
- Guaranteed zero errors, or a proven 0% false auto-accept rate — 0% is
  the **safety target**, not a claim of achieved performance
- A full offline speech-to-text pipeline for voice reports (voice upload is
  accepted and clearly labelled as a transcription **simulation**)

| Label | Meaning |
|---|---|
| **IMPLEMENTED** | Real, working code path exercised by the golden demo |
| **SIMULATED** | Present for demo completeness but not a full production implementation (e.g. voice transcription) |
| **PROTOTYPE** | Functionally real but explicitly not production-hardened (e.g. P6 export format) |
| **FUTURE INTEGRATION** | Designed for, not built (e.g. live Primavera P6 API, PostgreSQL in production) |

## 16. Future Scope

- Live, read/write Primavera P6 integration via Oracle's API (not just an
  export package)
- Full offline ASR pipeline for voice field reports
- spaCy-based NER model fine-tuned on labelled OIL DPR data, replacing/
  augmenting the regex extractor
- Horizontal scaling test against a real 50,000+ activity Primavera export
- Contractor-facing mobile app for field report submission
- Configurable QA gate rules per activity type / discipline

---

*PlanBridge — a PlanBridge team submission for SIH26122, Oil India Limited (OIL).*
