import React from "react";
import { ShieldCheck, ShieldX, ShieldQuestion } from "lucide-react";
import type { QARecord } from "../types";

const icons: Record<string, any> = { PASSED: ShieldCheck, FAILED: ShieldX, PENDING: ShieldQuestion };
const colors: Record<string, string> = {
  PASSED: "text-emerald-600", FAILED: "text-rose-600", PENDING: "text-amber-500",
};

export default function QATimeline({ records }: { records: QARecord[] }) {
  if (records.length === 0) return <p className="text-sm text-slate-400">No QA records yet.</p>;
  return (
    <div className="space-y-3">
      {records.map((r) => {
        const Icon = icons[r.status] || ShieldQuestion;
        return (
          <div key={r.id} className="flex items-start gap-3 border-l-2 border-slate-200 pl-3 py-1">
            <Icon size={18} className={`mt-0.5 ${colors[r.status]}`} />
            <div>
              <div className="text-sm font-medium text-slate-800">
                {r.inspection_type} — <span className={colors[r.status]}>{r.status}</span>
              </div>
              <div className="text-xs text-slate-500">{r.inspector} · {new Date(r.date).toLocaleString()}</div>
              {r.comments && <div className="text-xs text-slate-500 mt-0.5">{r.comments}</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}
