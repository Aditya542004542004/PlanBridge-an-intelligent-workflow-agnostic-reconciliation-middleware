import React from "react";
import { useNavigate } from "react-router-dom";
import type { Activity } from "../types";

// Simplified Gantt-style bar view (not a full scheduling engine) — renders
// each activity as a horizontal timeline bar sized by physical progress,
// with a darker overlay for verified progress, per spec section 18.
export default function GanttChart({ activities }: { activities: Activity[] }) {
  const navigate = useNavigate();
  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
          <tr>
            <th className="px-4 py-2 text-left">Activity ID</th>
            <th className="px-4 py-2 text-left">Name</th>
            <th className="px-4 py-2 text-left w-64">Progress</th>
            <th className="px-4 py-2 text-left">Status</th>
          </tr>
        </thead>
        <tbody>
          {activities.map((a) => (
            <tr key={a.id} className="border-t border-slate-100 hover:bg-slate-50 cursor-pointer" onClick={() => navigate(`/activities/${a.id}`)}>
              <td className="px-4 py-2 font-mono text-xs text-oil-700">{a.activity_id}</td>
              <td className="px-4 py-2">{a.name}</td>
              <td className="px-4 py-2">
                <div className="w-56 h-3 bg-slate-100 rounded relative overflow-hidden">
                  <div className="absolute inset-y-0 left-0 bg-oil-300/60 bg-oil-600" style={{ width: `${Math.min(a.physical_progress_pct, 100)}%`, backgroundColor: "#93c5fd" }} />
                  <div className="absolute inset-y-0 left-0 bg-emerald-500" style={{ width: `${Math.min(a.verified_progress_pct, 100)}%` }} />
                </div>
              </td>
              <td className="px-4 py-2">{a.status.replace("_", " ")}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
