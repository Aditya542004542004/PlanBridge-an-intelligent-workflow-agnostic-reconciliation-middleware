import React from "react";
import type { EntitiesOut } from "../types";

export default function EntityPanel({ entities }: { entities: EntitiesOut }) {
  const rows: [string, React.ReactNode][] = [
    ["KP", entities.kp || "—"],
    ["Line Number", entities.line_number || "—"],
    ["Location", entities.location || "—"],
    ["Activity Type", entities.activity_type || "—"],
    ["Raw Quantity", entities.quantity_raw_value != null ? `${entities.quantity_raw_value} ${entities.quantity_raw_unit}` : "—"],
    ["Normalized Quantity", entities.quantity_normalized_value != null
      ? `${entities.quantity_normalized_value} ${entities.quantity_normalized_unit}`
      : <span className="text-amber-600">{entities.conversion_status}</span>],
    ["Conversion Rule", <span className="font-mono text-xs">{entities.conversion_rule || "—"}</span>],
  ];
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4">
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Extracted Entities & Unit Normalization</h3>
      <dl className="grid grid-cols-2 gap-y-2 text-sm">
        {rows.map(([k, v]) => (
          <React.Fragment key={k as string}>
            <dt className="text-slate-500">{k}</dt>
            <dd className="text-slate-800 font-medium">{v}</dd>
          </React.Fragment>
        ))}
      </dl>
    </div>
  );
}
