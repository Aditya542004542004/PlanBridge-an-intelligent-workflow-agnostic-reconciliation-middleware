import React from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard, FolderKanban, ListChecks, FileInput, Cpu, GitMerge,
  ClipboardCheck, ShieldCheck, TrendingUp, GanttChartSquare, FileClock,
  UploadCloud, Settings, FlaskConical,
} from "lucide-react";

const items = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/projects", label: "Projects", icon: FolderKanban },
  { to: "/activities", label: "Schedule / Activities", icon: ListChecks },
  { to: "/reports", label: "Field Reports", icon: FileInput },
  { to: "/processing", label: "Report Processing", icon: Cpu },
  { to: "/matching", label: "Matching Engine", icon: GitMerge },
  { to: "/review-queue", label: "Planner Review Queue", icon: ClipboardCheck },
  { to: "/qa", label: "QA/QC", icon: ShieldCheck },
  { to: "/progress", label: "Progress Tracking", icon: TrendingUp },
  { to: "/gantt", label: "Gantt View", icon: GanttChartSquare },
  { to: "/evidence", label: "Evidence & Audit", icon: FileClock },
  { to: "/export", label: "P6 Export", icon: UploadCloud },
  { to: "/evaluation", label: "Evaluation", icon: FlaskConical },
  { to: "/settings", label: "Settings", icon: Settings },
];

export default function Sidebar() {
  return (
    <aside className="w-64 bg-oil-900 text-slate-200 flex flex-col shrink-0 min-h-screen">
      <div className="px-5 py-5 border-b border-white/10">
        <div className="text-lg font-bold text-white">PlanBridge</div>
        <div className="text-[11px] text-slate-400">From Field Reality to Schedule Truth</div>
      </div>
      <nav className="flex-1 overflow-y-auto py-3">
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-5 py-2.5 text-sm transition-colors ${
                isActive ? "bg-white/10 text-white border-l-2 border-oil-accent" : "text-slate-300 hover:bg-white/5 hover:text-white border-l-2 border-transparent"
              }`
            }
          >
            <Icon size={16} />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="px-5 py-3 text-[10px] text-slate-500 border-t border-white/10">
        SIH26122 · Oil India Limited (OIL) prototype
      </div>
    </aside>
  );
}
