import React, { useState } from "react";
import { X } from "lucide-react";
import { api } from "../api/client";
import type { Activity } from "../types";

export default function ExportModal({
  projectId, activities, onClose,
}: { projectId: number; activities: Activity[]; onClose: () => void }) {
  const [selected, setSelected] = useState<number[]>(activities.map((a) => a.id));
  const [format, setFormat] = useState("CSV");
  const [content, setContent] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function toggle(id: number) {
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  }

  async function generate() {
    setBusy(true);
    try {
      const res: any = await api.createExport({ project_id: projectId, activity_ids: selected, format });
      setContent(res.content);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[85vh] overflow-y-auto p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-800">P6 Update Package</h2>
          <button onClick={onClose}><X size={20} /></button>
        </div>
        <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-4">
          Prototype P6-compatible export representation — this does not connect to a live Primavera P6 instance.
        </p>

        <div className="mb-3 flex items-center gap-3">
          <label className="text-sm font-medium">Format:</label>
          <select value={format} onChange={(e) => setFormat(e.target.value)} className="border border-slate-200 rounded-lg px-2 py-1 text-sm">
            <option value="CSV">CSV</option>
            <option value="XML">XML</option>
          </select>
        </div>

        <div className="max-h-48 overflow-y-auto border border-slate-100 rounded-lg mb-4">
          {activities.map((a) => (
            <label key={a.id} className="flex items-center gap-2 px-3 py-1.5 text-sm border-b border-slate-50 last:border-0">
              <input type="checkbox" checked={selected.includes(a.id)} onChange={() => toggle(a.id)} />
              <span className="font-mono text-xs text-oil-700">{a.activity_id}</span>
              <span className="text-slate-500 truncate">{a.name}</span>
              <span className="ml-auto text-xs text-slate-400">Phys {a.physical_progress_pct}% / Ver {a.verified_progress_pct}%</span>
            </label>
          ))}
        </div>

        <button disabled={busy || selected.length === 0} onClick={generate} className="bg-oil-700 hover:bg-oil-800 disabled:opacity-40 text-white text-sm font-medium px-4 py-2 rounded-lg">
          Generate & Approve Export
        </button>

        {content && (
          <pre className="mt-4 bg-slate-900 text-slate-100 text-xs p-3 rounded-lg overflow-x-auto max-h-64">{content}</pre>
        )}
      </div>
    </div>
  );
}
