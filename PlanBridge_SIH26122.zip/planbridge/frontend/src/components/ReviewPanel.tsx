import React, { useState } from "react";
import CandidateCard from "./CandidateCard";
import MatchExplanation from "./MatchExplanation";
import type { MatchCandidate } from "../types";
import { api } from "../api/client";

export default function ReviewPanel({
  reportText, candidates, onDecision,
}: { reportText: string; candidates: MatchCandidate[]; onDecision: () => void }) {
  const [busy, setBusy] = useState(false);
  const top = candidates[0];
  const others = candidates.slice(1);

  async function approve() {
    if (!top) return;
    setBusy(true);
    try {
      await api.approveMatch(top.match_id);
      onDecision();
    } finally {
      setBusy(false);
    }
  }

  async function reject() {
    if (!top) return;
    setBusy(true);
    try {
      await api.rejectMatch(top.match_id);
      onDecision();
    } finally {
      setBusy(false);
    }
  }

  async function reassign(candidate: MatchCandidate) {
    if (!top) return;
    setBusy(true);
    try {
      await api.approveMatch(top.match_id, "Reassigned by planner", candidate.activity.id);
      onDecision();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <h3 className="text-xs font-semibold uppercase text-slate-500 mb-2">Field Report</h3>
        <p className="text-sm text-slate-700 font-mono">{reportText}</p>
      </div>

      {top && (
        <>
          <h3 className="text-xs font-semibold uppercase text-slate-500">Top Match</h3>
          <CandidateCard candidate={top} highlight />
          <MatchExplanation candidate={top} />

          {others.length > 0 && (
            <>
              <h3 className="text-xs font-semibold uppercase text-slate-500 mt-4">Other Candidates</h3>
              <div className="space-y-2">
                {others.map((c) => (
                  <div key={c.match_id} className="flex items-center gap-3">
                    <div className="flex-1"><CandidateCard candidate={c} /></div>
                    <button
                      disabled={busy}
                      onClick={() => reassign(c)}
                      className="text-xs px-3 py-2 border border-slate-200 rounded-lg hover:bg-slate-50"
                    >
                      Select Instead
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}

          <div className="flex gap-3 pt-2">
            <button disabled={busy} onClick={approve} className="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium px-4 py-2 rounded-lg">
              Approve
            </button>
            <button disabled={busy} onClick={reject} className="bg-rose-600 hover:bg-rose-700 text-white text-sm font-medium px-4 py-2 rounded-lg">
              Reject / Send to Unmatched
            </button>
          </div>
        </>
      )}
      {!top && <p className="text-slate-400 text-sm">No candidates were found for this report.</p>}
    </div>
  );
}
