import React, { useState } from "react";
import { X, ArrowRight } from "lucide-react";

const STEPS = [
  { title: "Field report received", detail: "A field engineer submits: \"150m HDD drilling completed today near KP 24+600 at river site.\" Stored with a SHA-256 hash — go to Field Reports." },
  { title: "Entities extracted", detail: "KP = 24+600, Work = HDD drilling, Quantity = 150, Location = river site — see Report Processing." },
  { title: "Units normalized", detail: "150 m is deterministically converted (e.g. to 0.150 km when the target activity uses km) — never guessed by an LLM." },
  { title: "Activities searched", detail: "Stage 1 entity filtering narrows 50,000+ activities down to a handful of candidates sharing KP / activity type / location." },
  { title: "AI ranking", detail: "Stage 2 semantic ranking scores each candidate against the report text — see Matching Engine." },
  { title: "Confidence decision", detail: "Final score = 45% semantic + 35% entity + 20% quantity. >85% AUTO-LINK, 60-85% PLANNER REVIEW, <60% UNMATCHED." },
  { title: "Physical progress calculated", detail: "150m reported / 500m planned = 30% Physical Progress." },
  { title: "QA verification", detail: "A second report — \"NDT radiography passed for 150m HDD at KP 24+600\" — flips QA to PASSED." },
  { title: "Evidence generated", detail: "An evidence record with a SHA-256 tamper-detection fingerprint is created and linked to the report and activity." },
  { title: "Planner approval", detail: "Medium-confidence or reassigned matches wait in the Planner Review Queue until approved." },
  { title: "P6 export", detail: "Once approved, a prototype P6-compatible CSV/XML update package can be generated from the Export page." },
];

export default function DemoModeModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState(0);
  const s = STEPS[step];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs font-semibold text-oil-700 uppercase">Demo Mode · Step {step + 1} / {STEPS.length}</span>
          <button onClick={onClose}><X size={20} /></button>
        </div>
        <h2 className="text-xl font-bold text-slate-800 mb-2">{s.title}</h2>
        <p className="text-sm text-slate-600 mb-6">{s.detail}</p>
        <div className="flex justify-between">
          <button disabled={step === 0} onClick={() => setStep((s) => s - 1)}
            className="text-sm text-slate-500 disabled:opacity-30 px-3 py-2">Back</button>
          {step < STEPS.length - 1 ? (
            <button onClick={() => setStep((s) => s + 1)}
              className="flex items-center gap-1 bg-oil-700 hover:bg-oil-800 text-white text-sm font-medium px-4 py-2 rounded-lg">
              Next <ArrowRight size={16} />
            </button>
          ) : (
            <button onClick={onClose} className="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium px-4 py-2 rounded-lg">
              Finish
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
