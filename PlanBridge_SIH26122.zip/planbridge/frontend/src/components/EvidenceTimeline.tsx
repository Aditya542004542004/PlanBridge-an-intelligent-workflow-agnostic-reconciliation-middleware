import React from "react";
import { FileDigit } from "lucide-react";
import type { EvidenceEntry } from "../types";

export default function EvidenceTimeline({ entries }: { entries: EvidenceEntry[] }) {
  if (entries.length === 0) return <p className="text-sm text-slate-400">No evidence recorded yet.</p>;
  return (
    <div className="space-y-3">
      {entries.map((e) => (
        <div key={e.id} className="flex items-start gap-3 border-l-2 border-oil-200 pl-3 py-1">
          <FileDigit size={18} className="mt-0.5 text-oil-700" />
          <div>
            <div className="text-sm font-medium text-slate-800">
              Quantity {e.quantity} · Reporter: {e.reporter} · QA: {e.qa_status}
            </div>
            <div className="text-xs font-mono text-slate-400 break-all">{e.sha256_hash}</div>
            <div className="text-xs text-slate-400">{new Date(e.created_at).toLocaleString()} — {e.note}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
