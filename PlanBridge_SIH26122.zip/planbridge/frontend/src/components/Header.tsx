import React from "react";
import { LogOut } from "lucide-react";
import { clearAuth } from "../api/client";
import { useNavigate } from "react-router-dom";

export default function Header({ title, subtitle }: { title: string; subtitle?: string }) {
  const navigate = useNavigate();
  const fullName = localStorage.getItem("planbridge_name") || "";
  const role = localStorage.getItem("planbridge_role") || "";

  return (
    <header className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200">
      <div>
        <h1 className="text-xl font-bold text-slate-800">{title}</h1>
        {subtitle && <p className="text-sm text-slate-500">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-4">
        <div className="text-right">
          <div className="text-sm font-semibold text-slate-700">{fullName}</div>
          <div className="text-xs text-slate-400">{role}</div>
        </div>
        <button
          onClick={() => { clearAuth(); navigate("/login"); }}
          className="flex items-center gap-1 text-sm text-slate-500 hover:text-rose-600"
        >
          <LogOut size={16} /> Logout
        </button>
      </div>
    </header>
  );
}
