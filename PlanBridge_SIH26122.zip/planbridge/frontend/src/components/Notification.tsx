import React, { useEffect } from "react";
import { X, CheckCircle2, AlertTriangle, Info } from "lucide-react";

export type NotificationKind = "success" | "error" | "info";

export default function Notification({
  message, kind = "info", onClose,
}: { message: string; kind?: NotificationKind; onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 5000);
    return () => clearTimeout(t);
  }, [onClose]);

  const styles: Record<NotificationKind, string> = {
    success: "bg-emerald-50 border-emerald-200 text-emerald-800",
    error: "bg-rose-50 border-rose-200 text-rose-800",
    info: "bg-slate-50 border-slate-200 text-slate-800",
  };
  const Icon = kind === "success" ? CheckCircle2 : kind === "error" ? AlertTriangle : Info;

  return (
    <div className={`fixed bottom-4 right-4 z-50 flex items-start gap-2 border rounded-lg px-4 py-3 shadow-lg max-w-sm ${styles[kind]}`}>
      <Icon size={18} className="mt-0.5 shrink-0" />
      <p className="text-sm">{message}</p>
      <button onClick={onClose} className="ml-auto text-slate-400 hover:text-slate-600">
        <X size={16} />
      </button>
    </div>
  );
}
