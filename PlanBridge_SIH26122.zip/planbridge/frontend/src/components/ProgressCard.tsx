import React from "react";

export default function ProgressCard({ physical, verified }: { physical: number; verified: number }) {
  return (
    <div className="space-y-2">
      <div>
        <div className="flex justify-between text-xs mb-1">
          <span className="font-medium text-slate-600">Physical Progress</span>
          <span className="font-semibold text-oil-700">{physical.toFixed(1)}%</span>
        </div>
        <div className="w-full bg-slate-100 rounded-full h-2">
          <div className="bg-oil-600 h-2 rounded-full" style={{ width: `${Math.min(physical, 100)}%` }} />
        </div>
      </div>
      <div>
        <div className="flex justify-between text-xs mb-1">
          <span className="font-medium text-slate-600">QA-Verified Progress</span>
          <span className="font-semibold text-emerald-700">{verified.toFixed(1)}%</span>
        </div>
        <div className="w-full bg-slate-100 rounded-full h-2">
          <div className="bg-emerald-500 h-2 rounded-full" style={{ width: `${Math.min(verified, 100)}%` }} />
        </div>
      </div>
    </div>
  );
}
