import React from "react";
import { useNavigate } from "react-router-dom";
import type { Activity } from "../types";

const statusColor: Record<string, string> = {
  NOT_STARTED: "bg-slate-100 text-slate-600",
  IN_PROGRESS: "bg-blue-100 text-blue-700",
  COMPLETE: "bg-emerald-100 text-emerald-700",
};

export default function ActivityTable({ activities }: { activities: Activity[] }) {
  const navigate = useNavigate();
  return (
    <div className="overflow-x-auto bg-white rounded-xl border border-slate-200">
      <table className="min-w-full text-sm">
        <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
          <tr>
            <th className="px-4 py-2 text-left">Activity ID</th>
            <th className="px-4 py-2 text-left">Name</th>
            <th className="px-4 py-2 text-left">KP</th>
            <th className="px-4 py-2 text-left">Planned Qty</th>
            <th className="px-4 py-2 text-left">Physical %</th>
            <th className="px-4 py-2 text-left">Verified %</th>
            <th className="px-4 py-2 text-left">Status</th>
          </tr>
        </thead>
        <tbody>
          {activities.map((a) => (
            <tr
              key={a.id}
              className="border-t border-slate-100 hover:bg-slate-50 cursor-pointer"
              onClick={() => navigate(`/activities/${a.id}`)}
            >
              <td className="px-4 py-2 font-mono text-xs text-oil-700">{a.activity_id}</td>
              <td className="px-4 py-2">{a.name}</td>
              <td className="px-4 py-2">{a.kp}</td>
              <td className="px-4 py-2">{a.planned_quantity} {a.planned_unit}</td>
              <td className="px-4 py-2">{a.physical_progress_pct.toFixed(1)}%</td>
              <td className="px-4 py-2">{a.verified_progress_pct.toFixed(1)}%</td>
              <td className="px-4 py-2">
                <span className={`badge ${statusColor[a.status] || "bg-slate-100 text-slate-600"}`}>
                  {a.status.replace("_", " ")}
                </span>
              </td>
            </tr>
          ))}
          {activities.length === 0 && (
            <tr><td colSpan={7} className="px-4 py-6 text-center text-slate-400">No activities found.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
