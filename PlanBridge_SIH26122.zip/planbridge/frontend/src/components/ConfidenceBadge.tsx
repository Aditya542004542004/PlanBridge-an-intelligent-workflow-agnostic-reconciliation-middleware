import React from "react";

export default function ConfidenceBadge({ decision, confidence }: { decision: string; confidence: number }) {
  const styles: Record<string, string> = {
    AUTO_LINK: "bg-emerald-100 text-emerald-700",
    PLANNER_REVIEW: "bg-amber-100 text-amber-700",
    UNMATCHED: "bg-rose-100 text-rose-700",
  };
  const labels: Record<string, string> = {
    AUTO_LINK: "AUTO-LINK",
    PLANNER_REVIEW: "PLANNER REVIEW",
    UNMATCHED: "UNMATCHED",
  };
  return (
    <span className={`badge ${styles[decision] || "bg-slate-100 text-slate-600"}`}>
      {labels[decision] || decision} · {confidence.toFixed(1)}%
    </span>
  );
}
