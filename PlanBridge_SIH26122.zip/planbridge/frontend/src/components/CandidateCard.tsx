import React from "react";
import ConfidenceBadge from "./ConfidenceBadge";
import type { MatchCandidate } from "../types";

export default function CandidateCard({ candidate, highlight }: { candidate: MatchCandidate; highlight?: boolean }) {
  return (
    <div className={`rounded-lg border p-3 ${highlight ? "border-oil-600 bg-oil-50" : "border-slate-200 bg-white"}`}>
      <div className="flex items-center justify-between">
        <div>
          <div className="font-mono text-xs text-oil-700">{candidate.activity.activity_id}</div>
          <div className="text-sm font-medium text-slate-800">{candidate.activity.name}</div>
        </div>
        <ConfidenceBadge decision={candidate.decision} confidence={candidate.final_confidence} />
      </div>
      <div className="mt-2 grid grid-cols-3 gap-2 text-xs text-slate-500">
        <div>Semantic: <span className="font-semibold text-slate-700">{candidate.semantic_score}%</span></div>
        <div>Entity: <span className="font-semibold text-slate-700">{candidate.entity_score}%</span></div>
        <div>Quantity: <span className="font-semibold text-slate-700">{candidate.quantity_score}%</span></div>
      </div>
    </div>
  );
}
