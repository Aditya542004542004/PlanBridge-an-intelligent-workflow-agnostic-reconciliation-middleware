import React from "react";
import { Check, X } from "lucide-react";
import type { MatchCandidate } from "../types";

function Row({ ok, label }: { ok: boolean; label: string }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      {ok ? <Check size={16} className="text-emerald-600" /> : <X size={16} className="text-rose-500" />}
      <span className={ok ? "text-slate-700" : "text-slate-400"}>{label}</span>
    </div>
  );
}

export default function MatchExplanation({ candidate }: { candidate: MatchCandidate }) {
  const e = candidate.explanation || {};
  const qty = e.quantity_compatibility || {};
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4">
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Why This Match?</h3>
      <div className="space-y-1.5">
        <Row ok={!!e.kp_match} label={`KP matched`} />
        <Row ok={!!e.activity_type_match} label="Activity type matched" />
        <Row ok={!!e.location_match} label="Location matched" />
        <Row ok={(e.semantic_similarity_pct || 0) >= 60} label={`Semantic similarity: ${e.semantic_similarity_pct ?? "—"}%`} />
        <Row ok={!!qty.compatible} label={`Quantity compatible ${qty.ratio != null ? `(ratio ${qty.ratio})` : ""}`} />
      </div>
      <div className="mt-3 pt-3 border-t border-slate-100 text-sm">
        <span className="text-slate-500">Final Decision: </span>
        <span className="font-bold text-oil-700">{candidate.decision.replace("_", " ")}</span>
      </div>
    </div>
  );
}
