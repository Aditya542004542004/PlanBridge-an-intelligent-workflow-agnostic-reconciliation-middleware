import React from "react";
import type { AuditEntry } from "../types";

export default function AuditTable({ entries }: { entries: AuditEntry[] }) {
  return (
    <div className="overflow-x-auto bg-white rounded-xl border border-slate-200">
      <table className="min-w-full text-sm">
        <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
          <tr>
            <th className="px-4 py-2 text-left">Event</th>
            <th className="px-4 py-2 text-left">Actor</th>
            <th className="px-4 py-2 text-left">Report</th>
            <th className="px-4 py-2 text-left">Activity</th>
            <th className="px-4 py-2 text-left">Timestamp</th>
          </tr>
        </thead>
        <tbody>
          {entries.map((e) => (
            <tr key={e.id} className="border-t border-slate-100">
              <td className="px-4 py-2 font-medium text-oil-700">{e.event_type}</td>
              <td className="px-4 py-2">{e.actor}</td>
              <td className="px-4 py-2">{e.report_id ?? "—"}</td>
              <td className="px-4 py-2">{e.activity_id ?? "—"}</td>
              <td className="px-4 py-2 text-slate-500">{new Date(e.timestamp).toLocaleString()}</td>
            </tr>
          ))}
          {entries.length === 0 && (
            <tr><td colSpan={5} className="px-4 py-6 text-center text-slate-400">No audit events yet.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
