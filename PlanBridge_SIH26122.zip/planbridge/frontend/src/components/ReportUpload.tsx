import React, { useState } from "react";
import { UploadCloud, FileText } from "lucide-react";
import { api } from "../api/client";

export default function ReportUpload({ projectId, onUploaded }: { projectId: number; onUploaded: () => void }) {
  const [text, setText] = useState("");
  const [reporter, setReporter] = useState("");
  const [busy, setBusy] = useState(false);
  const [file, setFile] = useState<File | null>(null);

  async function submitText() {
    if (!text.trim()) return;
    setBusy(true);
    try {
      await api.submitTextReport({ project_id: projectId, raw_text: text, reporter_name: reporter, source_type: "MANUAL" });
      setText("");
      onUploaded();
    } finally {
      setBusy(false);
    }
  }

  async function submitFile() {
    if (!file) return;
    setBusy(true);
    try {
      await api.uploadReport(projectId, file, reporter);
      setFile(null);
      onUploaded();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-4">
      <div>
        <label className="text-xs font-semibold text-slate-500 uppercase">Reporter Name</label>
        <input
          value={reporter}
          onChange={(e) => setReporter(e.target.value)}
          className="mt-1 w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
          placeholder="e.g. Farhan Field"
        />
      </div>

      <div>
        <label className="text-xs font-semibold text-slate-500 uppercase">Manual Text Report</label>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={4}
          className="mt-1 w-full border border-slate-200 rounded-lg px-3 py-2 text-sm font-mono"
          placeholder='e.g. "150m HDD drilling completed today near KP 24+600 at river site."'
        />
        <button
          disabled={busy || !text.trim()}
          onClick={submitText}
          className="mt-2 bg-oil-700 hover:bg-oil-800 disabled:opacity-40 text-white text-sm font-medium px-4 py-2 rounded-lg"
        >
          Submit Text Report
        </button>
      </div>

      <div className="border-t border-slate-100 pt-4">
        <label className="text-xs font-semibold text-slate-500 uppercase">Upload File (PDF / Excel / CSV / TXT / Voice)</label>
        <div className="mt-2 flex items-center gap-3">
          <label className="flex items-center gap-2 border border-dashed border-slate-300 rounded-lg px-4 py-3 cursor-pointer text-sm text-slate-500 hover:border-oil-600">
            <UploadCloud size={18} />
            {file ? file.name : "Choose file"}
            <input type="file" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          </label>
          <button
            disabled={busy || !file}
            onClick={submitFile}
            className="bg-oil-700 hover:bg-oil-800 disabled:opacity-40 text-white text-sm font-medium px-4 py-2 rounded-lg flex items-center gap-2"
          >
            <FileText size={16} /> Upload
          </button>
        </div>
      </div>
    </div>
  );
}
