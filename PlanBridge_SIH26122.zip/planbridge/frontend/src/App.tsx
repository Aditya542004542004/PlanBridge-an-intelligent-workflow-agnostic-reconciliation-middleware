import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import { loadAuth } from "./api/client";

import LoginPage from "./pages/LoginPage";
import DashboardPage from "./pages/DashboardPage";
import ProjectsPage from "./pages/ProjectsPage";
import ActivitiesPage from "./pages/ActivitiesPage";
import ActivityDetailPage from "./pages/ActivityDetailPage";
import FieldReportsPage from "./pages/FieldReportsPage";
import ReportProcessingPage from "./pages/ReportProcessingPage";
import MatchingEnginePage from "./pages/MatchingEnginePage";
import ReviewQueuePage from "./pages/ReviewQueuePage";
import QAPage from "./pages/QAPage";
import ProgressPage from "./pages/ProgressPage";
import GanttPage from "./pages/GanttPage";
import EvidenceAuditPage from "./pages/EvidenceAuditPage";
import ExportPage from "./pages/ExportPage";
import EvaluationPage from "./pages/EvaluationPage";
import SettingsPage from "./pages/SettingsPage";

function Protected({ children }: { children: React.ReactNode }) {
  const auth = loadAuth();
  if (!auth) return <Navigate to="/login" replace />;
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 min-h-screen">{children}</div>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/dashboard" element={<Protected><DashboardPage /></Protected>} />
      <Route path="/projects" element={<Protected><ProjectsPage /></Protected>} />
      <Route path="/activities" element={<Protected><ActivitiesPage /></Protected>} />
      <Route path="/activities/:id" element={<Protected><ActivityDetailPage /></Protected>} />
      <Route path="/reports" element={<Protected><FieldReportsPage /></Protected>} />
      <Route path="/processing" element={<Protected><ReportProcessingPage /></Protected>} />
      <Route path="/matching" element={<Protected><MatchingEnginePage /></Protected>} />
      <Route path="/review-queue" element={<Protected><ReviewQueuePage /></Protected>} />
      <Route path="/qa" element={<Protected><QAPage /></Protected>} />
      <Route path="/progress" element={<Protected><ProgressPage /></Protected>} />
      <Route path="/gantt" element={<Protected><GanttPage /></Protected>} />
      <Route path="/evidence" element={<Protected><EvidenceAuditPage /></Protected>} />
      <Route path="/export" element={<Protected><ExportPage /></Protected>} />
      <Route path="/evaluation" element={<Protected><EvaluationPage /></Protected>} />
      <Route path="/settings" element={<Protected><SettingsPage /></Protected>} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
