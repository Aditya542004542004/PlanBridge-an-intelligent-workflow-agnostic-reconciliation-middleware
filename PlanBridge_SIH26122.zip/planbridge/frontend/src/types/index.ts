export interface AuthState {
  token: string;
  role: string;
  fullName: string;
  email: string;
}

export interface Project {
  id: number;
  code: string;
  name: string;
  description: string;
}

export interface Activity {
  id: number;
  activity_id: string;
  name: string;
  activity_type: string;
  kp: string;
  location_tag: string;
  planned_quantity: number;
  planned_unit: string;
  status: string;
  physical_progress_pct: number;
  verified_progress_pct: number;
}

export interface FieldReport {
  id: number;
  project_id: number;
  reporter_name: string;
  source_type: string;
  original_filename: string;
  raw_text: string;
  sha256_hash: string;
  processing_status: string;
  is_duplicate: boolean;
  created_at: string;
}

export interface EntitiesOut {
  kp?: string;
  line_number?: string;
  location?: string;
  activity_type?: string;
  quantity_raw_value?: number;
  quantity_raw_unit?: string;
  quantity_normalized_value?: number;
  quantity_normalized_unit?: string;
  conversion_rule?: string;
  conversion_status?: string;
}

export interface MatchCandidate {
  match_id: number;
  activity: Activity;
  entity_score: number;
  semantic_score: number;
  quantity_score: number;
  final_confidence: number;
  decision: "AUTO_LINK" | "PLANNER_REVIEW" | "UNMATCHED";
  explanation: Record<string, any>;
  rank: number;
}

export interface MatchRunResponse {
  report_id: number;
  candidates: MatchCandidate[];
  backend: string;
}

export interface QARecord {
  id: number;
  activity_id: number;
  inspection_type: string;
  status: "PENDING" | "PASSED" | "FAILED";
  inspector: string;
  date: string;
  comments: string;
}

export interface DashboardStats {
  total_projects: number;
  total_activities: number;
  reports_processed: number;
  auto_linked: number;
  planner_reviews: number;
  unmatched: number;
  qa_pending: number;
  qa_verified: number;
  avg_physical_progress: number;
  avg_verified_progress: number;
  false_auto_accept_rate: number | null;
  reports_by_source: Record<string, number>;
  activity_status_breakdown: Record<string, number>;
}

export interface AuditEntry {
  id: number;
  event_type: string;
  actor: string;
  report_id: number | null;
  activity_id: number | null;
  details: Record<string, any>;
  timestamp: string;
}

export interface EvidenceEntry {
  id: number;
  report_id: number;
  quantity: number;
  reporter: string;
  qa_status: string;
  sha256_hash: string;
  created_at: string;
  note: string;
}
