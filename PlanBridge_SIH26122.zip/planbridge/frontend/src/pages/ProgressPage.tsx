import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import ProgressCard from "../components/ProgressCard";
import { api } from "../api/client";
import type { Activity } from "../types";

export default function ProgressPage() {
  const [activities, setActivities] = useState<Activity[]>([]);
  useEffect(() => { api.listActivities().then((r: any) => setActivities(r)); }, []);

  return (
    <div>
      <Header title="Progress Tracking" subtitle="Physical progress vs QA-verified progress — never merged" />
      <div className="p-6 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {activities.map((a) => (
          <div key={a.id} className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="font-mono text-xs text-oil-700">{a.activity_id}</div>
            <div className="text-sm font-semibold text-slate-800 mb-3 truncate">{a.name}</div>
            <ProgressCard physical={a.physical_progress_pct} verified={a.verified_progress_pct} />
          </div>
        ))}
        {activities.length === 0 && <p className="text-slate-400">No activities found.</p>}
      </div>
    </div>
  );
}
