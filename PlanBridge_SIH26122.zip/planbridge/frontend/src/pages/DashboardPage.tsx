import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import StatCard from "../components/StatCard";
import {
  FolderKanban, ListChecks, FileInput, GitMerge, ClipboardCheck, XCircle,
  ShieldCheck, ShieldQuestion, TrendingUp, PlayCircle,
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { api } from "../api/client";
import type { DashboardStats } from "../types";
import DemoModeModal from "../components/DemoModeModal";

const COLORS = ["#134a75", "#1a659e", "#e8a33d", "#10b981", "#ef4444"];

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [showDemo, setShowDemo] = useState(false);

  useEffect(() => { api.dashboard().then((r: any) => setStats(r)); }, []);

  if (!stats) return <div className="p-6 text-slate-400">Loading dashboard...</div>;

  const progressData = [
    { name: "Physical", value: stats.avg_physical_progress },
    { name: "Verified", value: stats.avg_verified_progress },
  ];
  const matchData = [
    { name: "Auto-Linked", value: stats.auto_linked },
    { name: "Planner Review", value: stats.planner_reviews },
    { name: "Unmatched", value: stats.unmatched },
  ];
  const qaData = [
    { name: "Pending", value: stats.qa_pending },
    { name: "Verified", value: stats.qa_verified },
  ];
  const sourceData = Object.entries(stats.reports_by_source).map(([name, value]) => ({ name, value }));
  const statusData = Object.entries(stats.activity_status_breakdown).map(([name, value]) => ({ name, value }));

  return (
    <div>
      <Header title="Dashboard" subtitle="OIL Duliajan 50 KM Pipeline Project — synthetic demo data" />
      <div className="p-6 space-y-6">
        <div className="flex justify-between items-center">
          <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            Safety Target: <strong>0% False Auto-Accept</strong> · Measured rate: {stats.false_auto_accept_rate ?? "not yet evaluated"}%
          </div>
          <button onClick={() => setShowDemo(true)} className="flex items-center gap-2 bg-oil-accent hover:brightness-95 text-oil-900 font-semibold text-sm px-4 py-2 rounded-lg">
            <PlayCircle size={18} /> DEMO MODE
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <StatCard label="Total Projects" value={stats.total_projects} icon={<FolderKanban size={18} />} />
          <StatCard label="Total Activities" value={stats.total_activities} icon={<ListChecks size={18} />} />
          <StatCard label="Reports Processed" value={stats.reports_processed} icon={<FileInput size={18} />} />
          <StatCard label="Auto-Linked" value={stats.auto_linked} icon={<GitMerge size={18} />} accent="text-emerald-600" />
          <StatCard label="Planner Reviews" value={stats.planner_reviews} icon={<ClipboardCheck size={18} />} accent="text-amber-600" />
          <StatCard label="Unmatched" value={stats.unmatched} icon={<XCircle size={18} />} accent="text-rose-600" />
          <StatCard label="QA Pending" value={stats.qa_pending} icon={<ShieldQuestion size={18} />} accent="text-amber-600" />
          <StatCard label="QA Verified" value={stats.qa_verified} icon={<ShieldCheck size={18} />} accent="text-emerald-600" />
          <StatCard label="Avg Physical Progress" value={`${stats.avg_physical_progress}%`} icon={<TrendingUp size={18} />} />
          <StatCard label="Avg Verified Progress" value={`${stats.avg_verified_progress}%`} icon={<TrendingUp size={18} />} accent="text-emerald-600" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ChartCard title="Physical vs Verified Progress">
            <BarChart data={progressData} width={420} height={220}>
              <XAxis dataKey="name" fontSize={12} /><YAxis fontSize={12} /><Tooltip />
              <Bar dataKey="value" fill="#134a75" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ChartCard>

          <ChartCard title="Matching Confidence Breakdown">
            <PieChart width={420} height={220}>
              <Pie data={matchData} dataKey="value" nameKey="name" outerRadius={80} label>
                {matchData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Legend /><Tooltip />
            </PieChart>
          </ChartCard>

          <ChartCard title="QA Status">
            <BarChart data={qaData} width={420} height={220}>
              <XAxis dataKey="name" fontSize={12} /><YAxis fontSize={12} /><Tooltip />
              <Bar dataKey="value" fill="#e8a33d" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ChartCard>

          <ChartCard title="Reports by Source">
            <PieChart width={420} height={220}>
              <Pie data={sourceData} dataKey="value" nameKey="name" outerRadius={80} label>
                {sourceData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Legend /><Tooltip />
            </PieChart>
          </ChartCard>

          <ChartCard title="Activity Status">
            <BarChart data={statusData} width={420} height={220}>
              <XAxis dataKey="name" fontSize={12} /><YAxis fontSize={12} /><Tooltip />
              <Bar dataKey="value" fill="#1a659e" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ChartCard>
        </div>
      </div>
      {showDemo && <DemoModeModal onClose={() => setShowDemo(false)} />}
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4">
      <h3 className="text-sm font-semibold text-slate-700 mb-2">{title}</h3>
      {children}
    </div>
  );
}
