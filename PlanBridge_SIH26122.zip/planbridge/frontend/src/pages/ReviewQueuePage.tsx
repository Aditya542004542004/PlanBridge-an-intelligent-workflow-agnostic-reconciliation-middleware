import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import ReviewPanel from "../components/ReviewPanel";
import { api } from "../api/client";
import type { MatchCandidate, FieldReport } from "../types";

export default function ReviewQueuePage() {
  const [queue, setQueue] = useState<MatchCandidate[]>([]);
  const [selected, setSelected] = useState<MatchCandidate | null>(null);
  const [reportText, setReportText] = useState("");
  const [allCandidatesForReport, setAllCandidatesForReport] = useState<MatchCandidate[]>([]);

  function refresh() {
    api.reviewQueue().then((r: any) => {
      setQueue(r);
      setSelected(null);
    });
  }

  useEffect(refresh, []);

  async function openItem(item: MatchCandidate) {
    setSelected(item);
    const res: any = await api.getMatches(item.report_id);
    setAllCandidatesForReport(res.candidates);
    const reports: FieldReport[] = await api.listReports() as any;
    const report = reports.find((r) => r.id === item.report_id);
    setReportText(report?.raw_text || "");
  }

  return (
    <div>
      <Header title="Planner Review Queue" subtitle="Medium-confidence matches awaiting a human decision" />
      <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 bg-white rounded-xl border border-slate-200 p-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">Queue ({queue.length})</h3>
          <div className="space-y-2">
            {queue.map((item) => (
              <button
                key={item.match_id}
                onClick={() => openItem(item)}
                className={`w-full text-left text-sm px-3 py-2 rounded-lg border ${selected?.match_id === item.match_id ? "border-oil-600 bg-oil-50" : "border-slate-100 hover:bg-slate-50"}`}
              >
                <div className="font-mono text-xs text-oil-700">{item.activity.activity_id}</div>
                <div className="text-slate-700 truncate">{item.activity.name}</div>
                <div className="text-xs text-amber-600">{item.final_confidence}% confidence</div>
              </button>
            ))}
            {queue.length === 0 && <p className="text-slate-400 text-sm">Queue is empty — nothing awaiting review.</p>}
          </div>
        </div>

        <div className="lg:col-span-2">
          {selected ? (
            <ReviewPanel reportText={reportText} candidates={allCandidatesForReport} onDecision={refresh} />
          ) : (
            <p className="text-slate-400 text-sm">Select an item from the queue to review it.</p>
          )}
        </div>
      </div>
    </div>
  );
}
