import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, saveAuth } from "../api/client";

const DEMO_ACCOUNTS = [
  ["admin@planbridge.demo", "ADMIN"],
  ["planner@planbridge.demo", "PLANNER"],
  ["qa@planbridge.demo", "QA_ENGINEER"],
  ["manager@planbridge.demo", "PROJECT_MANAGER"],
  ["field@planbridge.demo", "FIELD_ENGINEER"],
];

export default function LoginPage() {
  const [email, setEmail] = useState("planner@planbridge.demo");
  const [password, setPassword] = useState("PlanBridge@2026");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res: any = await api.login(email, password);
      saveAuth(res.access_token, res.role, res.full_name, email);
      navigate("/dashboard");
    } catch (err: any) {
      setError(err.message || "Login failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-oil-900 px-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-8">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-oil-900">PlanBridge</h1>
          <p className="text-sm text-slate-500 mt-1">From Field Reality to Schedule Truth</p>
          <p className="text-[11px] text-slate-400 mt-1">SIH26122 · Oil India Limited (OIL) prototype</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase">Email</label>
            <input value={email} onChange={(e) => setEmail(e.target.value)} type="email"
              className="mt-1 w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase">Password</label>
            <input value={password} onChange={(e) => setPassword(e.target.value)} type="password"
              className="mt-1 w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
          </div>
          {error && <p className="text-sm text-rose-600">{error}</p>}
          <button disabled={busy} type="submit"
            className="w-full bg-oil-700 hover:bg-oil-800 disabled:opacity-50 text-white font-medium py-2.5 rounded-lg">
            {busy ? "Signing in..." : "Sign In"}
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-slate-100">
          <p className="text-xs font-semibold text-slate-500 uppercase mb-2">Demo Accounts (password: PlanBridge@2026)</p>
          <div className="grid grid-cols-1 gap-1">
            {DEMO_ACCOUNTS.map(([em, role]) => (
              <button key={em} onClick={() => setEmail(em)} type="button"
                className="text-left text-xs px-2 py-1 rounded hover:bg-slate-50 text-slate-600">
                {em} <span className="text-slate-400">— {role}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
