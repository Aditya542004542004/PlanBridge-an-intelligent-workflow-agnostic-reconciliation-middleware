import React from "react";
import Header from "../components/Header";

export default function SettingsPage() {
  const role = localStorage.getItem("planbridge_role");
  return (
    <div>
      <Header title="Settings" subtitle="Confidence engine configuration & system info" />
      <div className="p-6 space-y-4 max-w-2xl">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-2">Confidence Engine Weights</h3>
          <p className="text-sm text-slate-500 mb-3">
            Configured in the backend at <code className="bg-slate-100 px-1 rounded">app/core/config.py</code> (change and restart to apply):
          </p>
          <ul className="text-sm text-slate-700 space-y-1">
            <li>Semantic Similarity: <strong>45%</strong></li>
            <li>Entity Match: <strong>35%</strong></li>
            <li>Quantity Consistency: <strong>20%</strong></li>
          </ul>
          <ul className="text-sm text-slate-700 space-y-1 mt-2">
            <li>Auto-Link threshold: <strong>&gt; 85%</strong></li>
            <li>Planner Review threshold: <strong>60% – 85%</strong></li>
            <li>Unmatched: <strong>&lt; 60%</strong></li>
          </ul>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-2">Your Session</h3>
          <p className="text-sm text-slate-600">Role: <strong>{role}</strong></p>
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
          This is a hackathon prototype (SIH26122). It does not connect to any live OIL system,
          live Primavera P6 instance, or real confidential OIL data. See the README for full
          IMPLEMENTED / SIMULATED / PROTOTYPE / FUTURE INTEGRATION labelling.
        </div>
      </div>
    </div>
  );
}
