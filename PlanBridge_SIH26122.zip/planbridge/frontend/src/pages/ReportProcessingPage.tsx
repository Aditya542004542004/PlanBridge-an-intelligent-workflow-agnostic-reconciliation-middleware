import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import EntityPanel from "../components/EntityPanel";
import { api } from "../api/client";
import type { FieldReport, EntitiesOut } from "../types";

export default function ReportProcessingPage() {
  const [reports, setReports] = useState<FieldReport[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [entities, setEntities] = useState<EntitiesOut | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.listReports().then((r: any) => {
      setReports(r);
      if (r.length) setSelectedId(r[0].id);
    });
  }, []);

  const selected = reports.find((r) => r.id === selectedId);

  async function process() {
    if (!selectedId) return;
    setBusy(true);
    try {
      const res: any = await api.processReport(selectedId);
      setEntities(res);
      api.listReports().then((r: any) => setReports(r));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <Header title="Report Processing" subtitle="RAW REPORT → Entity Extraction → Deterministic Unit Normalization" />
      <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 bg-white rounded-xl border border-slate-200 p-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">Select a Field Report</h3>
          <div className="space-y-2 max-h-[60vh] overflow-y-auto">
            {reports.map((r) => (
              <button
                key={r.id}
                onClick={() => { setSelectedId(r.id); setEntities(null); }}
                className={`w-full text-left text-sm px-3 py-2 rounded-lg border ${selectedId === r.id ? "border-oil-600 bg-oil-50" : "border-slate-100 hover:bg-slate-50"}`}
              >
                <div className="font-medium text-slate-700 truncate">#{r.id} — {r.raw_text}</div>
                <div className="text-xs text-slate-400">{r.processing_status}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="lg:col-span-2 space-y-4">
          {selected && (
            <div className="bg-white rounded-xl border border-slate-200 p-4">
              <h3 className="text-xs font-semibold uppercase text-slate-500 mb-2">Raw Report</h3>
              <p className="text-sm font-mono text-slate-700">{selected.raw_text}</p>
              <button disabled={busy} onClick={process} className="mt-3 bg-oil-700 hover:bg-oil-800 disabled:opacity-40 text-white text-sm font-medium px-4 py-2 rounded-lg">
                Extract Entities & Normalize Units
              </button>
            </div>
          )}
          {entities && <EntityPanel entities={entities} />}
        </div>
      </div>
    </div>
  );
}
