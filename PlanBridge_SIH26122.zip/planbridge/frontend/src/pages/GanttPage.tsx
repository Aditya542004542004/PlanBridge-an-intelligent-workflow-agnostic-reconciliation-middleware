import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import GanttChart from "../components/GanttChart";
import { api } from "../api/client";
import type { Activity } from "../types";

export default function GanttPage() {
  const [activities, setActivities] = useState<Activity[]>([]);
  useEffect(() => { api.listActivities().then((r: any) => setActivities(r)); }, []);

  return (
    <div>
      <Header title="Gantt View" subtitle="Blue = physical progress, Green = QA-verified progress. Click a row for full detail." />
      <div className="p-6"><GanttChart activities={activities} /></div>
    </div>
  );
}
