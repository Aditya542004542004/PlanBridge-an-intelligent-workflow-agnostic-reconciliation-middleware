import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import ExportModal from "../components/ExportModal";
import { api } from "../api/client";
import type { Activity, Project } from "../types";

export default function ExportPage() {
  const [project, setProject] = useState<Project | null>(null);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    api.listProjects().then((r: any) => {
      const p = r[0];
      setProject(p);
      if (p) api.listActivities({ project_id: p.id }).then((a: any) => setActivities(a.filter((x: Activity) => x.physical_progress_pct > 0)));
    });
  }, []);

  return (
    <div>
      <Header title="P6 Export" subtitle="Prototype P6-compatible export representation — no live Primavera connection" />
      <div className="p-6 space-y-4">
        <p className="text-sm text-slate-600">
          {activities.length} activities with reported progress are available to include in a P6 Update Package.
        </p>
        <button onClick={() => setShowModal(true)} className="bg-oil-700 hover:bg-oil-800 text-white text-sm font-medium px-4 py-2 rounded-lg">
          Build P6 Update Package
        </button>
      </div>
      {showModal && project && <ExportModal projectId={project.id} activities={activities} onClose={() => setShowModal(false)} />}
    </div>
  );
}
