import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import ReportUpload from "../components/ReportUpload";
import { api } from "../api/client";
import type { FieldReport, Project } from "../types";

export default function FieldReportsPage() {
  const [project, setProject] = useState<Project | null>(null);
  const [reports, setReports] = useState<FieldReport[]>([]);

  function refresh(projectId?: number) {
    api.listReports(projectId).then((r: any) => setReports(r));
  }

  useEffect(() => {
    api.listProjects().then((r: any) => {
      const p = r[0];
      setProject(p);
      refresh(p?.id);
    });
  }, []);

  return (
    <div>
      <Header title="Field Reports" subtitle="Unstructured DPRs, PDFs, Excel, CSV, TXT, and manual text" />
      <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          {project && <ReportUpload projectId={project.id} onUploaded={() => refresh(project.id)} />}
        </div>
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl border border-slate-200 overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                <tr>
                  <th className="px-4 py-2 text-left">#</th>
                  <th className="px-4 py-2 text-left">Reporter</th>
                  <th className="px-4 py-2 text-left">Source</th>
                  <th className="px-4 py-2 text-left">Text</th>
                  <th className="px-4 py-2 text-left">Status</th>
                  <th className="px-4 py-2 text-left">Duplicate?</th>
                </tr>
              </thead>
              <tbody>
                {reports.map((r) => (
                  <tr key={r.id} className="border-t border-slate-100">
                    <td className="px-4 py-2">{r.id}</td>
                    <td className="px-4 py-2">{r.reporter_name}</td>
                    <td className="px-4 py-2">{r.source_type}</td>
                    <td className="px-4 py-2 max-w-xs truncate" title={r.raw_text}>{r.raw_text}</td>
                    <td className="px-4 py-2">
                      <span className="badge bg-slate-100 text-slate-600">{r.processing_status}</span>
                    </td>
                    <td className="px-4 py-2">
                      {r.is_duplicate ? <span className="badge bg-rose-100 text-rose-700">DUPLICATE</span> : "—"}
                    </td>
                  </tr>
                ))}
                {reports.length === 0 && (
                  <tr><td colSpan={6} className="px-4 py-6 text-center text-slate-400">No reports yet.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
