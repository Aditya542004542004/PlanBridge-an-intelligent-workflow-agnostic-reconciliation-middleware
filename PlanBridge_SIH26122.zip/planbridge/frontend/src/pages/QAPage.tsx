import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import QATimeline from "../components/QATimeline";
import { api } from "../api/client";
import type { Activity } from "../types";

export default function QAPage() {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [activityId, setActivityId] = useState<number | null>(null);
  const [inspectionType, setInspectionType] = useState("NDT Radiography");
  const [status, setStatus] = useState("PASSED");
  const [inspector, setInspector] = useState("Qadir QA");
  const [comments, setComments] = useState("");
  const [records, setRecords] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.listActivities().then((r: any) => {
      setActivities(r);
      if (r.length) setActivityId(r[0].id);
    });
  }, []);

  function refreshRecords(id: number) {
    api.listQA(id).then((r: any) => setRecords(r));
  }

  useEffect(() => { if (activityId) refreshRecords(activityId); }, [activityId]);

  async function submit() {
    if (!activityId) return;
    setBusy(true);
    try {
      await api.createQA({ activity_id: activityId, inspection_type: inspectionType, status, inspector, comments });
      refreshRecords(activityId);
      setComments("");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <Header title="QA / QC" subtitle="Quality gates that unlock QA-verified progress" />
      <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 bg-white rounded-xl border border-slate-200 p-4 space-y-3">
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase">Activity</label>
            <select value={activityId ?? ""} onChange={(e) => setActivityId(Number(e.target.value))}
              className="mt-1 w-full border border-slate-200 rounded-lg px-3 py-2 text-sm">
              {activities.map((a) => <option key={a.id} value={a.id}>{a.activity_id} — {a.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase">Inspection Type</label>
            <input value={inspectionType} onChange={(e) => setInspectionType(e.target.value)}
              className="mt-1 w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase">Status</label>
            <select value={status} onChange={(e) => setStatus(e.target.value)} className="mt-1 w-full border border-slate-200 rounded-lg px-3 py-2 text-sm">
              <option value="PENDING">PENDING</option>
              <option value="PASSED">PASSED</option>
              <option value="FAILED">FAILED</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase">Inspector</label>
            <input value={inspector} onChange={(e) => setInspector(e.target.value)}
              className="mt-1 w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase">Comments</label>
            <textarea value={comments} onChange={(e) => setComments(e.target.value)} rows={2}
              className="mt-1 w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
          </div>
          <button disabled={busy} onClick={submit} className="w-full bg-oil-700 hover:bg-oil-800 disabled:opacity-40 text-white text-sm font-medium px-4 py-2 rounded-lg">
            Submit QA Record
          </button>
        </div>

        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">QA Timeline</h3>
          <QATimeline records={records} />
        </div>
      </div>
    </div>
  );
}
