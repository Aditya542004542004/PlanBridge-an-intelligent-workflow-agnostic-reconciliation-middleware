import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import ActivityTable from "../components/ActivityTable";
import { api } from "../api/client";
import type { Activity } from "../types";

export default function ActivitiesPage() {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [statusFilter, setStatusFilter] = useState("");
  const [search, setSearch] = useState("");

  useEffect(() => { api.listActivities(statusFilter ? { status: statusFilter } as any : {}).then((r: any) => setActivities(r)); }, [statusFilter]);

  const filtered = activities.filter((a) =>
    !search || a.activity_id.toLowerCase().includes(search.toLowerCase()) || a.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <Header title="Schedule / Activities" subtitle="Primavera-style planned activities" />
      <div className="p-6 space-y-4">
        <div className="flex gap-3">
          <input
            value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by activity ID or name..."
            className="border border-slate-200 rounded-lg px-3 py-2 text-sm w-72"
          />
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="border border-slate-200 rounded-lg px-3 py-2 text-sm">
            <option value="">All Statuses</option>
            <option value="NOT_STARTED">Not Started</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="COMPLETE">Complete</option>
          </select>
        </div>
        <ActivityTable activities={filtered} />
      </div>
    </div>
  );
}
