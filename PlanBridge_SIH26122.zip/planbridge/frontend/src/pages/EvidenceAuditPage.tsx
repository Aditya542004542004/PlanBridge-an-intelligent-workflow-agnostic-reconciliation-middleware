import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import AuditTable from "../components/AuditTable";
import { api } from "../api/client";

export default function EvidenceAuditPage() {
  const [audit, setAudit] = useState<any[]>([]);
  useEffect(() => { api.getAudit().then((r: any) => setAudit(r)); }, []);

  return (
    <div>
      <Header title="Evidence & Audit" subtitle="Full traceable history of every action in PlanBridge" />
      <div className="p-6 space-y-4">
        <p className="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
          SHA-256 fingerprints throughout PlanBridge are used for tamper detection, not blockchain-grade immutability.
          Open any activity's detail page for its full evidence timeline.
        </p>
        <AuditTable entries={audit} />
      </div>
    </div>
  );
}
