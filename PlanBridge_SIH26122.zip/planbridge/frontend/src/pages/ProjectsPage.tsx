import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import { api } from "../api/client";
import type { Project } from "../types";
import { FolderKanban } from "lucide-react";

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  useEffect(() => { api.listProjects().then((r: any) => setProjects(r)); }, []);

  return (
    <div>
      <Header title="Projects" subtitle="Projects registered in PlanBridge" />
      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        {projects.map((p) => (
          <div key={p.id} className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="flex items-center gap-2 text-oil-700 mb-2">
              <FolderKanban size={18} />
              <span className="font-mono text-xs">{p.code}</span>
            </div>
            <h3 className="text-lg font-bold text-slate-800">{p.name}</h3>
            <p className="text-sm text-slate-500 mt-1">{p.description}</p>
          </div>
        ))}
        {projects.length === 0 && <p className="text-slate-400">No projects found.</p>}
      </div>
    </div>
  );
}
