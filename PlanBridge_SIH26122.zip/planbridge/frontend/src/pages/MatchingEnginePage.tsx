import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import CandidateCard from "../components/CandidateCard";
import MatchExplanation from "../components/MatchExplanation";
import { api } from "../api/client";
import type { FieldReport, MatchCandidate } from "../types";

export default function MatchingEnginePage() {
  const [reports, setReports] = useState<FieldReport[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [candidates, setCandidates] = useState<MatchCandidate[]>([]);
  const [backend, setBackend] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    api.listReports().then((r: any) => {
      setReports(r);
      if (r.length) setSelectedId(r[0].id);
    });
  }, []);

  const selected = reports.find((r) => r.id === selectedId);

  async function run() {
    if (!selectedId) return;
    setBusy(true);
    setError("");
    try {
      const res: any = await api.runMatching(selectedId);
      setCandidates(res.candidates);
      setBackend(res.backend);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <Header title="Matching Engine" subtitle="Stage 1: Entity Filtering → Stage 2: Semantic Ranking → Confidence Gate" />
      <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 bg-white rounded-xl border border-slate-200 p-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">Select a Processed Report</h3>
          <div className="space-y-2 max-h-[60vh] overflow-y-auto">
            {reports.map((r) => (
              <button
                key={r.id}
                onClick={() => { setSelectedId(r.id); setCandidates([]); }}
                className={`w-full text-left text-sm px-3 py-2 rounded-lg border ${selectedId === r.id ? "border-oil-600 bg-oil-50" : "border-slate-100 hover:bg-slate-50"}`}
              >
                <div className="font-medium text-slate-700 truncate">#{r.id} — {r.raw_text}</div>
                <div className="text-xs text-slate-400">{r.processing_status}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="lg:col-span-2 space-y-4">
          {selected && (
            <div className="bg-white rounded-xl border border-slate-200 p-4 flex items-center justify-between">
              <p className="text-sm font-mono text-slate-700">{selected.raw_text}</p>
              <button disabled={busy} onClick={run} className="bg-oil-700 hover:bg-oil-800 disabled:opacity-40 text-white text-sm font-medium px-4 py-2 rounded-lg whitespace-nowrap ml-4">
                Run Matching
              </button>
            </div>
          )}
          {error && <p className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2">{error}</p>}
          {backend && <p className="text-xs text-slate-400">Semantic backend in use: <span className="font-mono">{backend}</span></p>}

          {candidates.map((c, i) => (
            <div key={c.match_id} className="space-y-2">
              <div className="text-xs font-semibold uppercase text-slate-500">Candidate {i + 1}</div>
              <CandidateCard candidate={c} highlight={i === 0} />
              {i === 0 && <MatchExplanation candidate={c} />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
