import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import { api } from "../api/client";
import type { Project } from "../types";

export default function EvaluationPage() {
  const [project, setProject] = useState<Project | null>(null);
  const [results, setResults] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { api.listProjects().then((r: any) => setProject(r[0])); }, []);

  async function run() {
    if (!project) return;
    setBusy(true);
    try {
      const r = await api.runEvaluation(project.id);
      setResults(r);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <Header title="Research Evaluation" subtitle="Keyword vs Semantic vs Hybrid PlanBridge matching" />
      <div className="p-6 space-y-4">
        <button disabled={busy || !project} onClick={run} className="bg-oil-700 hover:bg-oil-800 disabled:opacity-40 text-white text-sm font-medium px-4 py-2 rounded-lg">
          {busy ? "Running..." : "Run Synthetic Prototype Evaluation"}
        </button>

        {results && (
          <div>
            <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-4">
              {results.label} · Sample size: {results.sample_size} reports
            </p>
            <div className="overflow-x-auto bg-white rounded-xl border border-slate-200">
              <table className="min-w-full text-sm">
                <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                  <tr>
                    <th className="px-4 py-2 text-left">Method</th>
                    <th className="px-4 py-2 text-left">Top-1 Acc</th>
                    <th className="px-4 py-2 text-left">Top-3 Acc</th>
                    <th className="px-4 py-2 text-left">Precision</th>
                    <th className="px-4 py-2 text-left">Recall</th>
                    <th className="px-4 py-2 text-left">F1</th>
                    <th className="px-4 py-2 text-left">False Auto-Accept</th>
                    <th className="px-4 py-2 text-left">Avg Time (ms)</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(results.results).map(([method, m]: any) => (
                    <tr key={method} className="border-t border-slate-100">
                      <td className="px-4 py-2 font-semibold">{method}</td>
                      <td className="px-4 py-2">{m.top1_accuracy_pct}%</td>
                      <td className="px-4 py-2">{m.top3_accuracy_pct}%</td>
                      <td className="px-4 py-2">{m.precision}</td>
                      <td className="px-4 py-2">{m.recall}</td>
                      <td className="px-4 py-2">{m.f1}</td>
                      <td className="px-4 py-2">{m.false_auto_accept_rate_pct ?? "—"}</td>
                      <td className="px-4 py-2">{m.avg_processing_time_ms}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
