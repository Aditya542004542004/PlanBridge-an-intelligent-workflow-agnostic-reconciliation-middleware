import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Header from "../components/Header";
import ProgressCard from "../components/ProgressCard";
import QATimeline from "../components/QATimeline";
import EvidenceTimeline from "../components/EvidenceTimeline";
import AuditTable from "../components/AuditTable";
import { api } from "../api/client";

export default function ActivityDetailPage() {
  const { id } = useParams();
  const activityId = Number(id);
  const [detail, setDetail] = useState<any>(null);
  const [qa, setQa] = useState<any[]>([]);
  const [evidence, setEvidence] = useState<any[]>([]);
  const [audit, setAudit] = useState<any[]>([]);
  const [progress, setProgress] = useState<any>(null);

  function refresh() {
    api.getActivityDetail(activityId).then(setDetail);
    api.listQA(activityId).then((r: any) => setQa(r));
    api.getEvidence(activityId).then((r: any) => setEvidence(r));
    api.getAudit({ activity_id: activityId }).then((r: any) => setAudit(r));
    api.getProgress(activityId).then(setProgress);
  }

  useEffect(refresh, [activityId]);

  if (!detail) return <div className="p-6 text-slate-400">Loading...</div>;
  const a = detail.activity;

  return (
    <div>
      <Header title={a.activity_id} subtitle={a.name} />
      <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Schedule</h3>
            <dl className="text-sm space-y-1">
              <div className="flex justify-between"><dt className="text-slate-500">KP</dt><dd>{a.kp}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Location</dt><dd>{a.location_tag}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Type</dt><dd>{a.activity_type}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Planned Qty</dt><dd>{a.planned_quantity} {a.planned_unit}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Status</dt><dd>{a.status}</dd></div>
            </dl>
          </div>
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Progress</h3>
            <ProgressCard physical={a.physical_progress_pct} verified={a.verified_progress_pct} />
          </div>
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Matching History</h3>
            <div className="space-y-2 text-sm">
              {detail.matches.map((m: any) => (
                <div key={m.match_id} className="border-b border-slate-50 pb-1">
                  Report #{m.report_id} — {m.decision} ({m.final_confidence}%) — planner: {m.planner_decision}
                </div>
              ))}
              {detail.matches.length === 0 && <p className="text-slate-400">No matches yet.</p>}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <h3 className="text-sm font-semibold text-slate-700 mb-3">QA / QC</h3>
            <QATimeline records={qa} />
          </div>
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Evidence Timeline</h3>
            <EvidenceTimeline entries={evidence} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Audit Trail</h3>
            <AuditTable entries={audit} />
          </div>
        </div>
      </div>
    </div>
  );
}
