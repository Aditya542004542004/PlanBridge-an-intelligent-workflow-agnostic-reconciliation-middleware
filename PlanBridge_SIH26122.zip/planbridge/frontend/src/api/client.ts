const BASE_URL = "/api";

function getToken(): string | null {
  return localStorage.getItem("planbridge_token");
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string>),
  };
  if (!(options.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${BASE_URL}${path}`, { ...options, headers });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || `Request failed: ${res.status}`);
  }
  if (res.status === 204) return undefined as unknown as T;
  return res.json();
}

export const api = {
  login: (email: string, password: string) =>
    request<{ access_token: string; role: string; full_name: string }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),

  dashboard: (projectId?: number) =>
    request(`/dashboard${projectId ? `?project_id=${projectId}` : ""}`),

  listProjects: () => request("/projects"),

  listActivities: (params: { project_id?: number; status?: string } = {}) => {
    const qs = new URLSearchParams(params as any).toString();
    return request(`/activities${qs ? `?${qs}` : ""}`);
  },

  getActivityDetail: (id: number) => request(`/activities/${id}`),

  listReports: (projectId?: number) =>
    request(`/reports${projectId ? `?project_id=${projectId}` : ""}`),

  submitTextReport: (payload: { project_id: number; raw_text: string; reporter_name?: string; source_type?: string }) =>
    request("/reports/text", { method: "POST", body: JSON.stringify(payload) }),

  uploadReport: (projectId: number, file: File, reporterName = "") => {
    const form = new FormData();
    form.append("project_id", String(projectId));
    form.append("reporter_name", reporterName);
    form.append("file", file);
    return request("/reports/upload", { method: "POST", body: form });
  },

  processReport: (reportId: number) =>
    request(`/reports/${reportId}/process`, { method: "POST" }),

  runMatching: (reportId: number) =>
    request(`/matching/run/${reportId}`, { method: "POST" }),

  getMatches: (reportId: number) => request(`/matching/${reportId}`),

  reviewQueue: () => request("/review-queue"),

  approveMatch: (matchId: number, notes = "", reassignActivityId?: number) =>
    request(`/matches/${matchId}/approve`, {
      method: "POST",
      body: JSON.stringify({ notes, reassign_activity_id: reassignActivityId }),
    }),

  rejectMatch: (matchId: number, notes = "") =>
    request(`/matches/${matchId}/reject`, {
      method: "POST",
      body: JSON.stringify({ notes }),
    }),

  createQA: (payload: any) => request("/qa", { method: "POST", body: JSON.stringify(payload) }),

  listQA: (activityId?: number) =>
    request(`/qa${activityId ? `?activity_id=${activityId}` : ""}`),

  getProgress: (activityId: number) => request(`/progress/${activityId}`),

  getEvidence: (activityId: number) => request(`/evidence/${activityId}`),

  getAudit: (params: { activity_id?: number; report_id?: number } = {}) => {
    const qs = new URLSearchParams(params as any).toString();
    return request(`/audit${qs ? `?${qs}` : ""}`);
  },

  createExport: (payload: { project_id: number; activity_ids: number[]; format: string }) =>
    request("/exports", { method: "POST", body: JSON.stringify(payload) }),

  runEvaluation: (projectId: number) => request(`/evaluation/run?project_id=${projectId}`),

  health: () => request("/health"),
};

export function saveAuth(token: string, role: string, fullName: string, email: string) {
  localStorage.setItem("planbridge_token", token);
  localStorage.setItem("planbridge_role", role);
  localStorage.setItem("planbridge_name", fullName);
  localStorage.setItem("planbridge_email", email);
}

export function loadAuth() {
  const token = localStorage.getItem("planbridge_token");
  if (!token) return null;
  return {
    token,
    role: localStorage.getItem("planbridge_role") || "",
    fullName: localStorage.getItem("planbridge_name") || "",
    email: localStorage.getItem("planbridge_email") || "",
  };
}

export function clearAuth() {
  localStorage.removeItem("planbridge_token");
  localStorage.removeItem("planbridge_role");
  localStorage.removeItem("planbridge_name");
  localStorage.removeItem("planbridge_email");
}
