/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        oil: {
          900: "#0b2540",
          800: "#0f3057",
          700: "#134a75",
          600: "#1a659e",
          accent: "#e8a33d",
        },
      },
    },
  },
  plugins: [],
};
