"""
Deterministic unit normalizer.

IMPORTANT (spec section 9): unit conversion is pure arithmetic and must
NEVER be delegated to an LLM. Every conversion here is a fixed, testable
rule. Unknown / domain-specific units (e.g. "spools") are never guessed —
they are flagged UNKNOWN_UNIT and routed to planner review.
"""
from dataclasses import dataclass
from typing import Optional

# Canonical conversion table: (from_unit) -> (to_unit, multiplier)
# All conversions are exact and one-directional to a canonical base unit,
# then re-expressed in the target unit on demand.
_LENGTH_TO_METRES = {
    "mm": 0.001,
    "cm": 0.01,
    "m": 1.0,
    "km": 1000.0,
}
_MASS_TO_KG = {
    "kg": 1.0,
    "tonne": 1000.0,
    "tonnes": 1000.0,
    "t": 1000.0,
}

_UNIT_ALIASES = {
    "meter": "m", "meters": "m", "metre": "m", "metres": "m",
    "kilometer": "km", "kilometers": "km", "kilometre": "km", "kilometres": "km",
    "millimeter": "mm", "millimeters": "mm", "millimetre": "mm", "millimetres": "mm",
    "centimeter": "cm", "centimeters": "cm",
    "kg": "kg", "kgs": "kg", "kilogram": "kg", "kilograms": "kg",
    "tonne": "tonne", "tonnes": "tonne", "ton": "tonne", "tons": "tonne", "t": "tonne",
}

KNOWN_DOMAIN_UNITS_WITHOUT_CONVERSION = {"spool", "spools", "joint", "joints", "each", "no", "nos"}


@dataclass
class NormalizationResult:
    original_value: float
    original_unit: str
    normalized_value: Optional[float]
    normalized_unit: Optional[str]
    conversion_rule: str
    status: str  # OK, UNKNOWN_UNIT, MISSING, SAME_UNIT


def _canon_unit(unit: str) -> str:
    u = unit.strip().lower()
    return _UNIT_ALIASES.get(u, u)


def normalize_unit(value: Optional[float], unit: Optional[str], target_unit: str) -> NormalizationResult:
    """
    Convert `value` in `unit` to `target_unit` deterministically.
    Returns a NormalizationResult describing exactly what rule was applied
    (or why conversion could not be performed).
    """
    if value is None or unit is None or unit == "":
        return NormalizationResult(value or 0.0, unit or "", None, None, "no conversion possible", "MISSING")

    u = _canon_unit(unit)
    t = _canon_unit(target_unit)

    if u == t:
        return NormalizationResult(value, u, value, t, f"identity ({u} == {t})", "SAME_UNIT")

    if u in _LENGTH_TO_METRES and t in _LENGTH_TO_METRES:
        metres = value * _LENGTH_TO_METRES[u]
        converted = metres / _LENGTH_TO_METRES[t]
        rule = f"{value} {u} x {_LENGTH_TO_METRES[u]} = {metres} m; {metres} m / {_LENGTH_TO_METRES[t]} = {converted} {t}"
        return NormalizationResult(value, u, round(converted, 6), t, rule, "OK")

    if u in _MASS_TO_KG and t in _MASS_TO_KG:
        kg = value * _MASS_TO_KG[u]
        converted = kg / _MASS_TO_KG[t]
        rule = f"{value} {u} x {_MASS_TO_KG[u]} = {kg} kg; {kg} kg / {_MASS_TO_KG[t]} = {converted} {t}"
        return NormalizationResult(value, u, round(converted, 6), t, rule, "OK")

    # Domain-specific / unknown unit -> never guess, send to planner review
    return NormalizationResult(
        value, u, None, t,
        f"'{u}' is not a recognised convertible unit against target '{t}' — requires planner review",
        "UNKNOWN_UNIT",
    )
