"""
Entity extraction from unstructured field report text.

Uses regex-based, testable extraction rather than an opaque LLM call, so
behaviour is deterministic and explainable — a hard requirement for a
system that feeds a controlled Primavera export. Handles the KP formats
called out in the spec: "KP 24+600", "KP24+600", "Km 24+600", "24+600".
"""
import re
from dataclasses import dataclass, field
from typing import Optional

_KP_PATTERNS = [
    re.compile(r"\bKP\s*[:\-]?\s*(\d{1,4}\+\d{3})\b", re.IGNORECASE),
    re.compile(r"\bKm\s*[:\-]?\s*(\d{1,4}\+\d{3})\b", re.IGNORECASE),
    re.compile(r"(?<![\w])(\d{1,4}\+\d{3})(?![\w])"),
]

_LINE_PATTERN = re.compile(r"\bLine\s*[:\-]?\s*(\d{1,3})\b", re.IGNORECASE)

_QUANTITY_PATTERN = re.compile(
    r"(\d+(?:\.\d+)?)\s*(mm|cm|km|kg|tonnes?|t|m|spools?|joints?|nos\.?)\b", re.IGNORECASE
)

_ACTIVITY_KEYWORDS = {
    "HDD": ["hdd", "horizontal directional drilling", "directional drilling"],
    "WELDING": ["welding", "weld", "girth weld"],
    "VALVE_INSTALLATION": ["valve installation", "valve", "valves"],
    "NDT": ["ndt", "radiography", "radiographic", "x-ray"],
    "TRENCHING": ["trenching", "trench", "excavation"],
    "BACKFILL": ["backfill", "backfilling"],
    "COATING": ["coating", "wrapping"],
    "HYDROTEST": ["hydrotest", "hydrostatic test", "pressure test"],
}

_LOCATION_KEYWORDS = ["river site", "river crossing", "road crossing", "yard", "camp", "site"]

_EQUIPMENT_KEYWORDS = ["rig", "excavator", "crane", "welding machine", "hdd rig", "trencher", "bulldozer"]

_CONTRACTOR_PATTERN = re.compile(r"\bcontractor\s*[:\-]?\s*([A-Z][A-Za-z&.\s]{2,40})", re.IGNORECASE)


@dataclass
class ExtractedEntities:
    kp: Optional[str] = None
    line_number: Optional[str] = None
    location: Optional[str] = None
    activity_type: Optional[str] = None
    quantity_value: Optional[float] = None
    quantity_unit: Optional[str] = None
    contractor: Optional[str] = None
    equipment: Optional[str] = None
    matched_keywords: list = field(default_factory=list)


def _normalize_kp(raw: str) -> str:
    """Normalize any KP representation to the canonical 'XX+XXX' form."""
    digits = re.sub(r"[^\d+]", "", raw)
    return digits


def extract_entities(text: str) -> ExtractedEntities:
    result = ExtractedEntities()
    lower = text.lower()

    for pattern in _KP_PATTERNS:
        m = pattern.search(text)
        if m:
            result.kp = _normalize_kp(m.group(1))
            break

    line_match = _LINE_PATTERN.search(text)
    if line_match:
        result.line_number = line_match.group(1)

    qty_match = _QUANTITY_PATTERN.search(text)
    if qty_match:
        result.quantity_value = float(qty_match.group(1))
        result.quantity_unit = qty_match.group(2).lower()

    for activity_type, keywords in _ACTIVITY_KEYWORDS.items():
        for kw in keywords:
            if kw in lower:
                result.activity_type = activity_type
                result.matched_keywords.append(kw)
                break
        if result.activity_type:
            break

    for loc_kw in _LOCATION_KEYWORDS:
        if loc_kw in lower:
            result.location = loc_kw
            break

    for eq_kw in _EQUIPMENT_KEYWORDS:
        if eq_kw in lower:
            result.equipment = eq_kw
            break

    contractor_match = _CONTRACTOR_PATTERN.search(text)
    if contractor_match:
        result.contractor = contractor_match.group(1).strip()

    return result
