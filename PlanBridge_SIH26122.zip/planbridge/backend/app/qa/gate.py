"""
QA/QC domain logic. The QA gate itself lives alongside the dual progress
model in app.services.progress_service (activity_qa_passed,
refresh_verified_progress_after_qa) since the two are tightly coupled;
this module re-exports them so `from app.qa import ...` also works per the
backend folder structure required by the spec.
"""
from app.services.progress_service import activity_qa_passed, refresh_verified_progress_after_qa

__all__ = ["activity_qa_passed", "refresh_verified_progress_after_qa"]
