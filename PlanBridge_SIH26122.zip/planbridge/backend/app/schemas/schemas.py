from datetime import datetime
from typing import Optional, List, Any
from pydantic import BaseModel


class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    full_name: str


class ReportTextCreate(BaseModel):
    project_id: int
    raw_text: str
    reporter_name: str = ""
    source_type: str = "MANUAL"


class ReportOut(BaseModel):
    id: int
    project_id: int
    reporter_name: str
    source_type: str
    original_filename: str
    raw_text: str
    sha256_hash: str
    processing_status: str
    is_duplicate: bool
    created_at: datetime

    class Config:
        from_attributes = True


class EntitiesOut(BaseModel):
    kp: Optional[str] = None
    line_number: Optional[str] = None
    location: Optional[str] = None
    activity_type: Optional[str] = None
    quantity_raw_value: Optional[float] = None
    quantity_raw_unit: Optional[str] = None
    quantity_normalized_value: Optional[float] = None
    quantity_normalized_unit: Optional[str] = None
    conversion_rule: str = ""
    conversion_status: str = "OK"

    class Config:
        from_attributes = True


class ActivityOut(BaseModel):
    id: int
    activity_id: str
    name: str
    activity_type: str
    kp: str
    location_tag: str
    planned_quantity: float
    planned_unit: str
    status: str
    physical_progress_pct: float
    verified_progress_pct: float

    class Config:
        from_attributes = True


class MatchCandidateOut(BaseModel):
    match_id: int
    report_id: int
    activity: ActivityOut
    entity_score: float
    semantic_score: float
    quantity_score: float
    final_confidence: float
    decision: str
    explanation: dict
    rank: int


class MatchRunResponse(BaseModel):
    report_id: int
    candidates: List[MatchCandidateOut]
    backend: str


class MatchDecisionRequest(BaseModel):
    notes: str = ""
    reassign_activity_id: Optional[int] = None


class QACreate(BaseModel):
    activity_id: int
    report_id: Optional[int] = None
    inspection_type: str
    evidence: str = ""
    status: str = "PENDING"
    inspector: str = ""
    comments: str = ""


class QAOut(BaseModel):
    id: int
    activity_id: int
    inspection_type: str
    status: str
    inspector: str
    date: datetime
    comments: str

    class Config:
        from_attributes = True


class ExportRequest(BaseModel):
    project_id: int
    activity_ids: List[int]
    format: str = "CSV"


class DashboardStats(BaseModel):
    total_projects: int
    total_activities: int
    reports_processed: int
    auto_linked: int
    planner_reviews: int
    unmatched: int
    qa_pending: int
    qa_verified: int
    avg_physical_progress: float
    avg_verified_progress: float
    false_auto_accept_rate: Optional[float]
    reports_by_source: dict
    activity_status_breakdown: dict
