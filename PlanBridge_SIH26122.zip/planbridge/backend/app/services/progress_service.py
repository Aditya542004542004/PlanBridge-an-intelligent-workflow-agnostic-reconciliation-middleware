"""
Dual progress model (spec section 14).

PHYSICAL PROGRESS  = reported execution / planned quantity.
VERIFIED PROGRESS  = physical progress, but only counted once the
                      required QA gate has PASSED for that quantity.
The two numbers are always stored and displayed separately and are
NEVER merged into one another.
"""
from sqlalchemy.orm import Session
from app.models.models import Activity, ProgressRecord, QARecord


def calculate_physical_progress(reported_quantity: float, planned_quantity: float) -> float:
    if not planned_quantity:
        return 0.0
    pct = (reported_quantity / planned_quantity) * 100.0
    return round(min(pct, 100.0), 2)


def activity_qa_passed(db: Session, activity_id: int) -> bool:
    """True if the activity has at least one PASSED QA record and no unresolved FAILED gate blocking it."""
    passed = db.query(QARecord).filter(QARecord.activity_id == activity_id, QARecord.status == "PASSED").first()
    return passed is not None


def record_progress(db: Session, activity: Activity, report_id: int, reported_quantity: float, reported_unit: str) -> ProgressRecord:
    physical = calculate_physical_progress(reported_quantity, activity.planned_quantity)
    qa_ok = activity_qa_passed(db, activity.id)
    verified = physical if qa_ok else 0.0

    # Progress only ever moves forward for the demo's simple model
    activity.physical_progress_pct = max(activity.physical_progress_pct or 0.0, physical)
    activity.verified_progress_pct = max(activity.verified_progress_pct or 0.0, verified) if qa_ok else activity.verified_progress_pct

    if activity.physical_progress_pct > 0 and activity.status == "NOT_STARTED":
        activity.status = "IN_PROGRESS"
    if activity.physical_progress_pct >= 100:
        activity.status = "COMPLETE"

    record = ProgressRecord(
        activity_id=activity.id,
        report_id=report_id,
        reported_quantity=reported_quantity,
        reported_unit=reported_unit,
        physical_progress_pct=activity.physical_progress_pct,
        verified_progress_pct=activity.verified_progress_pct,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def refresh_verified_progress_after_qa(db: Session, activity: Activity) -> None:
    """Called after a QA record PASSES — recalculates verified progress to catch up to physical."""
    if activity_qa_passed(db, activity.id):
        activity.verified_progress_pct = activity.physical_progress_pct
        db.commit()
