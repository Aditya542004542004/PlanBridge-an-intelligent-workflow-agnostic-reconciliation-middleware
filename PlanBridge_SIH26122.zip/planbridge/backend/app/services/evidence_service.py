"""
Evidence & duplicate-detection utilities.

SHA-256 is used here as a TAMPER-DETECTION fingerprint, not as a claim of
immutability or blockchain-grade guarantees — the wording throughout the
app is careful about this (spec section 16).
"""
import hashlib
from sqlalchemy.orm import Session

from app.models.models import FieldReport, EvidenceRecord


def sha256_of_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def find_duplicate_report(db: Session, project_id: int, sha256_hash: str) -> FieldReport | None:
    """
    Duplicate detection based on content hash within the same project.
    A true duplicate is the same raw content reported again — this catches
    copy-pasted or re-submitted DPRs (spec section 25).
    """
    return (
        db.query(FieldReport)
        .filter(FieldReport.project_id == project_id, FieldReport.sha256_hash == sha256_hash)
        .first()
    )


def create_evidence_record(db: Session, report_id: int, activity_id: int | None,
                            quantity: float, reporter: str, qa_status: str, source_text: str) -> EvidenceRecord:
    fingerprint = sha256_of_text(f"{report_id}:{activity_id}:{quantity}:{reporter}:{source_text}")
    record = EvidenceRecord(
        report_id=report_id,
        activity_id=activity_id,
        quantity=quantity,
        reporter=reporter,
        qa_status=qa_status,
        sha256_hash=fingerprint,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record
