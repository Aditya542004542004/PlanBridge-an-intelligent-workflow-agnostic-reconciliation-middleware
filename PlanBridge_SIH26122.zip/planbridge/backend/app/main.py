from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.database import Base, engine
from app.api import auth, reports, matching, activities, qa, misc, evaluation

Base.metadata.create_all(bind=engine)

app = FastAPI(title=settings.APP_NAME, version="0.1.0",
              description="PlanBridge - From Field Reality to Schedule Truth (SIH26122 prototype)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(reports.router)
app.include_router(matching.router)
app.include_router(activities.router)
app.include_router(qa.router)
app.include_router(misc.router)
app.include_router(evaluation.router)


@app.get("/")
def root():
    return {"service": settings.APP_NAME, "status": "running", "docs": "/docs"}
