"""
SQLAlchemy ORM models for PlanBridge.

Implements the 15 tables required by the spec:
users, roles, projects, contractors, wbs_nodes, activities, field_reports,
report_entities, activity_matches, progress_records, qa_records,
evidence_records, planner_reviews, export_packages, audit_logs.

Indexes are added on project_id, activity_id, kp, location and status
columns per the performance requirements (section 23) so candidate
filtering stays fast even at tens of thousands of activities.
"""
from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Float, Boolean, Text, DateTime, ForeignKey, Index, JSON
)
from sqlalchemy.orm import relationship

from app.core.database import Base


class Role(Base):
    __tablename__ = "roles"
    id = Column(Integer, primary_key=True)
    name = Column(String(32), unique=True, nullable=False)
    # ADMIN, PLANNER, FIELD_ENGINEER, QA_ENGINEER, PROJECT_MANAGER

    users = relationship("User", back_populates="role")


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(128), unique=True, nullable=False, index=True)
    full_name = Column(String(128), nullable=False)
    hashed_password = Column(String(256), nullable=False)
    role_id = Column(Integer, ForeignKey("roles.id"), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    role = relationship("Role", back_populates="users")


class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True)
    code = Column(String(64), unique=True, nullable=False)
    name = Column(String(256), nullable=False)
    description = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    wbs_nodes = relationship("WBSNode", back_populates="project")
    activities = relationship("Activity", back_populates="project")
    field_reports = relationship("FieldReport", back_populates="project")


class Contractor(Base):
    __tablename__ = "contractors"
    id = Column(Integer, primary_key=True)
    name = Column(String(256), nullable=False)
    contact_email = Column(String(128), default="")


class WBSNode(Base):
    __tablename__ = "wbs_nodes"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), index=True, nullable=False)
    parent_id = Column(Integer, ForeignKey("wbs_nodes.id"), nullable=True)
    code = Column(String(64), nullable=False)
    name = Column(String(256), nullable=False)
    level = Column(Integer, default=1)

    project = relationship("Project", back_populates="wbs_nodes")


class Activity(Base):
    __tablename__ = "activities"
    id = Column(Integer, primary_key=True)
    activity_id = Column(String(64), unique=True, nullable=False, index=True)  # e.g. PIP-L5-024-003
    project_id = Column(Integer, ForeignKey("projects.id"), index=True, nullable=False)
    wbs_id = Column(Integer, ForeignKey("wbs_nodes.id"), nullable=True)
    name = Column(String(512), nullable=False)
    discipline = Column(String(64), default="", index=True)
    activity_type = Column(String(64), default="", index=True)  # HDD, WELDING, VALVE, ...
    kp = Column(String(32), default="", index=True)  # normalized "24+600"
    line_number = Column(String(32), default="")
    location_tag = Column(String(128), default="", index=True)
    planned_quantity = Column(Float, default=0.0)
    planned_unit = Column(String(16), default="m")
    planned_start = Column(DateTime, nullable=True)
    planned_finish = Column(DateTime, nullable=True)
    status = Column(String(32), default="NOT_STARTED", index=True)
    physical_progress_pct = Column(Float, default=0.0)
    verified_progress_pct = Column(Float, default=0.0)
    embedding = Column(JSON, nullable=True)  # precomputed & cached semantic embedding

    project = relationship("Project", back_populates="activities")
    matches = relationship("ActivityMatch", back_populates="activity")

    __table_args__ = (
        Index("ix_activity_project_status", "project_id", "status"),
    )


class FieldReport(Base):
    __tablename__ = "field_reports"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), index=True, nullable=False)
    contractor_id = Column(Integer, ForeignKey("contractors.id"), nullable=True)
    reporter_name = Column(String(128), default="")
    report_date = Column(DateTime, default=datetime.utcnow)
    source_type = Column(String(32), default="TEXT")  # PDF, EXCEL, CSV, TXT, MANUAL, VOICE
    original_filename = Column(String(256), default="")
    raw_text = Column(Text, nullable=False)
    sha256_hash = Column(String(64), index=True, nullable=False)
    processing_status = Column(String(32), default="RECEIVED", index=True)
    is_duplicate = Column(Boolean, default=False)
    duplicate_of_id = Column(Integer, ForeignKey("field_reports.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="field_reports")
    entities = relationship("ReportEntity", back_populates="report", uselist=False)
    matches = relationship("ActivityMatch", back_populates="report")


class ReportEntity(Base):
    __tablename__ = "report_entities"
    id = Column(Integer, primary_key=True)
    report_id = Column(Integer, ForeignKey("field_reports.id"), unique=True, index=True, nullable=False)
    kp = Column(String(32), default="")
    line_number = Column(String(32), default="")
    location = Column(String(128), default="")
    activity_type = Column(String(64), default="")
    quantity_raw_value = Column(Float, nullable=True)
    quantity_raw_unit = Column(String(16), default="")
    quantity_normalized_value = Column(Float, nullable=True)
    quantity_normalized_unit = Column(String(16), default="")
    conversion_rule = Column(String(128), default="")
    conversion_status = Column(String(32), default="OK")  # OK, UNKNOWN_UNIT, MISSING
    report_date_extracted = Column(String(64), default="")
    contractor_mentioned = Column(String(128), default="")
    equipment = Column(String(128), default="")

    report = relationship("FieldReport", back_populates="entities")


class ActivityMatch(Base):
    __tablename__ = "activity_matches"
    id = Column(Integer, primary_key=True)
    report_id = Column(Integer, ForeignKey("field_reports.id"), index=True, nullable=False)
    activity_id = Column(Integer, ForeignKey("activities.id"), index=True, nullable=False)
    entity_score = Column(Float, default=0.0)
    semantic_score = Column(Float, default=0.0)
    quantity_score = Column(Float, default=0.0)
    final_confidence = Column(Float, default=0.0)
    decision = Column(String(32), default="UNMATCHED", index=True)  # AUTO_LINK, PLANNER_REVIEW, UNMATCHED
    explanation = Column(JSON, default=dict)
    rank = Column(Integer, default=1)
    planner_decision = Column(String(32), default="PENDING")  # PENDING, APPROVED, REJECTED
    created_at = Column(DateTime, default=datetime.utcnow)

    report = relationship("FieldReport", back_populates="matches")
    activity = relationship("Activity", back_populates="matches")


class ProgressRecord(Base):
    __tablename__ = "progress_records"
    id = Column(Integer, primary_key=True)
    activity_id = Column(Integer, ForeignKey("activities.id"), index=True, nullable=False)
    report_id = Column(Integer, ForeignKey("field_reports.id"), nullable=True)
    reported_quantity = Column(Float, default=0.0)
    reported_unit = Column(String(16), default="m")
    physical_progress_pct = Column(Float, default=0.0)
    verified_progress_pct = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)


class QARecord(Base):
    __tablename__ = "qa_records"
    id = Column(Integer, primary_key=True)
    activity_id = Column(Integer, ForeignKey("activities.id"), index=True, nullable=False)
    report_id = Column(Integer, ForeignKey("field_reports.id"), nullable=True)
    inspection_type = Column(String(128), default="")  # e.g. NDT Radiography
    evidence = Column(Text, default="")
    status = Column(String(16), default="PENDING", index=True)  # PENDING, PASSED, FAILED
    inspector = Column(String(128), default="")
    date = Column(DateTime, default=datetime.utcnow)
    comments = Column(Text, default="")


class EvidenceRecord(Base):
    __tablename__ = "evidence_records"
    id = Column(Integer, primary_key=True)
    report_id = Column(Integer, ForeignKey("field_reports.id"), index=True, nullable=False)
    activity_id = Column(Integer, ForeignKey("activities.id"), index=True, nullable=True)
    quantity = Column(Float, default=0.0)
    reporter = Column(String(128), default="")
    qa_status = Column(String(16), default="PENDING")
    sha256_hash = Column(String(64), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class PlannerReview(Base):
    __tablename__ = "planner_reviews"
    id = Column(Integer, primary_key=True)
    match_id = Column(Integer, ForeignKey("activity_matches.id"), index=True, nullable=False)
    reviewer_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    decision = Column(String(32), default="PENDING")  # APPROVE, REJECT, REASSIGN, UNMATCHED, CLARIFY
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class ExportPackage(Base):
    __tablename__ = "export_packages"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    status = Column(String(32), default="DRAFT", index=True)  # DRAFT, APPROVED, GENERATED
    activity_ids = Column(JSON, default=list)
    format = Column(String(16), default="CSV")
    file_path = Column(String(512), default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True)
    event_type = Column(String(64), index=True, nullable=False)
    actor = Column(String(128), default="system")
    report_id = Column(Integer, ForeignKey("field_reports.id"), nullable=True)
    activity_id = Column(Integer, ForeignKey("activities.id"), nullable=True)
    details = Column(JSON, default=dict)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
