"""
Multi-format field report ingestion (spec section 7).

Supports PDF, Excel, CSV, TXT and raw manual text. Audio upload is
accepted for the prototype and surfaced as "Voice report received" with
a transcription-simulation fallback, since a full offline speech-to-text
stack is out of scope for a hackathon prototype (clearly labelled as
SIMULATED, never claimed as a live ASR integration).
"""
import io
from typing import Tuple

import pandas as pd


def parse_txt(raw_bytes: bytes) -> str:
    return raw_bytes.decode("utf-8", errors="ignore")


def parse_csv(raw_bytes: bytes) -> str:
    df = pd.read_csv(io.BytesIO(raw_bytes))
    return df.to_string(index=False)


def parse_excel(raw_bytes: bytes) -> str:
    df = pd.read_excel(io.BytesIO(raw_bytes))
    return df.to_string(index=False)


def parse_pdf(raw_bytes: bytes) -> str:
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(stream=raw_bytes, filetype="pdf")
        text = "\n".join(page.get_text() for page in doc)
        if text.strip():
            return text
    except Exception:
        pass
    return "[PDF text extraction unavailable in this environment — OCR fallback would run here.]"


def parse_audio_stub(filename: str) -> str:
    return (
        f"[VOICE REPORT RECEIVED: {filename}] "
        "Transcription simulated — full offline speech-to-text is out of scope for this prototype. "
        "Field engineer should confirm the transcribed text below before submission."
    )


def parse_upload(filename: str, raw_bytes: bytes, content_type: str) -> Tuple[str, str]:
    """Returns (extracted_text, source_type)."""
    lower = filename.lower()
    if lower.endswith(".pdf"):
        return parse_pdf(raw_bytes), "PDF"
    if lower.endswith(".xlsx") or lower.endswith(".xls"):
        return parse_excel(raw_bytes), "EXCEL"
    if lower.endswith(".csv"):
        return parse_csv(raw_bytes), "CSV"
    if lower.endswith(".txt"):
        return parse_txt(raw_bytes), "TXT"
    if lower.endswith((".wav", ".mp3", ".m4a", ".ogg")):
        return parse_audio_stub(filename), "VOICE"
    # default: try as text
    return parse_txt(raw_bytes), "TXT"
