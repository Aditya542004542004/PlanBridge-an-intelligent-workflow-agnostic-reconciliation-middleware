"""
Stage 1 of the hybrid matching engine: entity-based candidate filtering.

Cuts the search space from (potentially) 50,000+ activities down to a
handful of plausible candidates using cheap, indexed lookups (KP, line,
location, activity type) BEFORE any semantic inference runs. This keeps
the system usable at scale — semantic ranking (expensive) only ever runs
against a handful of rows, never the whole activities table.
"""
from typing import List
from sqlalchemy.orm import Session
from sqlalchemy import or_

from app.models.models import Activity
from app.normalization.entities import ExtractedEntities


def get_candidate_activities(db: Session, project_id: int, entities: ExtractedEntities, limit: int = 8) -> List[Activity]:
    query = db.query(Activity).filter(Activity.project_id == project_id)

    filters = []
    if entities.kp:
        filters.append(Activity.kp == entities.kp)
    if entities.activity_type:
        filters.append(Activity.activity_type == entities.activity_type)
    if entities.location:
        filters.append(Activity.location_tag.ilike(f"%{entities.location}%"))

    candidates: List[Activity] = []
    if filters:
        # Prefer rows matching ANY strong entity signal (still indexed lookups)
        candidates = query.filter(or_(*filters)).limit(limit * 3).all()

    if not candidates:
        # Nothing matched on hard entities — fall back to a bounded scan
        # of open activities in the project so semantic stage still has
        # something sensible to rank (still capped, never full-table for
        # very large projects thanks to the status index).
        candidates = query.filter(Activity.status != "COMPLETE").limit(limit * 3).all()

    return candidates[:limit]
