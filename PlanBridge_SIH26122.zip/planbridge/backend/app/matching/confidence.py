"""
Stage 2 of the hybrid matching engine: semantic ranking + explainable
confidence scoring.

Final Score = 45% Semantic + 35% Entity + 20% Quantity (weights are
configurable in app.core.config.Settings, per spec section 11).

Thresholds:
  > 85            -> AUTO_LINK
  60 - 85         -> PLANNER_REVIEW
  < 60            -> UNMATCHED
"""
from dataclasses import dataclass, field
from typing import List, Optional

from app.ai.embedder import semantic_similarity
from app.core.config import settings
from app.models.models import Activity
from app.normalization.entities import ExtractedEntities
from app.normalization.units import normalize_unit


@dataclass
class MatchResult:
    activity: Activity
    entity_score: float
    semantic_score: float
    quantity_score: float
    final_confidence: float
    decision: str
    explanation: dict = field(default_factory=dict)


def _entity_score(entities: ExtractedEntities, activity: Activity) -> (float, dict):
    checks = {}
    points = 0
    total = 0

    total += 1
    if entities.kp and activity.kp and entities.kp == activity.kp:
        points += 1
        checks["kp_match"] = True
    else:
        checks["kp_match"] = False

    total += 1
    if entities.activity_type and activity.activity_type and entities.activity_type == activity.activity_type:
        points += 1
        checks["activity_type_match"] = True
    else:
        checks["activity_type_match"] = False

    total += 1
    if entities.location and activity.location_tag and entities.location in activity.location_tag.lower():
        points += 1
        checks["location_match"] = True
    else:
        checks["location_match"] = False

    score = (points / total) * 100 if total else 0.0
    return score, checks


def _quantity_score(entities: ExtractedEntities, activity: Activity) -> (float, dict, Optional[float], str):
    """
    Quantity compatibility: reported quantity must be a sensible fraction
    of the planned quantity (0 < reported <= planned * 1.05 tolerance).
    Returns (score_0_100, details, normalized_reported_value, status).
    """
    if entities.quantity_value is None:
        return 0.0, {"quantity_present": False}, None, "MISSING"

    norm = normalize_unit(entities.quantity_value, entities.quantity_unit, activity.planned_unit)
    if norm.status == "UNKNOWN_UNIT":
        return 0.0, {"quantity_present": True, "unit_recognised": False}, None, "UNKNOWN_UNIT"

    reported = norm.normalized_value if norm.normalized_value is not None else entities.quantity_value
    planned = activity.planned_quantity or 0.0
    if planned <= 0:
        return 50.0, {"quantity_present": True, "planned_quantity_unknown": True}, reported, "OK"

    ratio = reported / planned
    compatible = 0.0 < ratio <= 1.05
    score = 100.0 if compatible else max(0.0, 100.0 - abs(ratio - 1.0) * 100)
    return score, {"quantity_present": True, "compatible": compatible, "ratio": round(ratio, 3)}, reported, "OK"


def score_candidates(entities: ExtractedEntities, report_text: str, candidates: List[Activity]) -> List[MatchResult]:
    results: List[MatchResult] = []
    for activity in candidates:
        entity_score, entity_checks = _entity_score(entities, activity)
        semantic_score = semantic_similarity(report_text, activity.name) * 100
        quantity_score, quantity_checks, normalized_qty, qty_status = _quantity_score(entities, activity)

        final = (
            settings.WEIGHT_SEMANTIC * semantic_score
            + settings.WEIGHT_ENTITY * entity_score
            + settings.WEIGHT_QUANTITY * quantity_score
        )

        if final > settings.THRESHOLD_AUTO_LINK:
            decision = "AUTO_LINK"
        elif final >= settings.THRESHOLD_PLANNER_REVIEW:
            decision = "PLANNER_REVIEW"
        else:
            decision = "UNMATCHED"

        explanation = {
            "kp_match": entity_checks.get("kp_match", False),
            "activity_type_match": entity_checks.get("activity_type_match", False),
            "location_match": entity_checks.get("location_match", False),
            "semantic_similarity_pct": round(semantic_score, 1),
            "quantity_compatibility": quantity_checks,
            "normalized_reported_quantity": normalized_qty,
            "quantity_status": qty_status,
            "weights": {
                "semantic": settings.WEIGHT_SEMANTIC,
                "entity": settings.WEIGHT_ENTITY,
                "quantity": settings.WEIGHT_QUANTITY,
            },
        }

        results.append(MatchResult(
            activity=activity,
            entity_score=round(entity_score, 2),
            semantic_score=round(semantic_score, 2),
            quantity_score=round(quantity_score, 2),
            final_confidence=round(final, 2),
            decision=decision,
            explanation=explanation,
        ))

    results.sort(key=lambda r: r.final_confidence, reverse=True)
    return results
