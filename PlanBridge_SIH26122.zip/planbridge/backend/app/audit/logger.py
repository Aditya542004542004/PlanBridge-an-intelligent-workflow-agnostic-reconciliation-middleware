"""
Central audit trail writer. Every important state-changing action in
PlanBridge must call log_event() so the full evidence/audit timeline
(spec section 16) can be reconstructed later.
"""
from sqlalchemy.orm import Session
from app.models.models import AuditLog

EVENT_TYPES = [
    "REPORT_RECEIVED", "REPORT_PROCESSED", "ENTITY_EXTRACTED", "MATCH_PROPOSED",
    "MATCH_ACCEPTED", "MATCH_REJECTED", "QA_SUBMITTED", "QA_APPROVED", "QA_FAILED",
    "PROGRESS_UPDATED", "EXPORT_GENERATED", "EXPORT_APPROVED", "DUPLICATE_FLAGGED",
]


def log_event(db: Session, event_type: str, actor: str = "system", report_id: int = None,
              activity_id: int = None, details: dict = None, commit: bool = True) -> AuditLog:
    entry = AuditLog(
        event_type=event_type,
        actor=actor,
        report_id=report_id,
        activity_id=activity_id,
        details=details or {},
    )
    db.add(entry)
    if commit:
        db.commit()
        db.refresh(entry)
    return entry
