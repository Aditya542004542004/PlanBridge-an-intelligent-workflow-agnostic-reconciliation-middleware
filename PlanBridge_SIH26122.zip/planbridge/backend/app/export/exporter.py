"""
"P6 Update Package" export (spec section 19).

IMPORTANT / HONESTY: this produces a *prototype P6-compatible export
representation* (CSV and a simple XML schedule-update schema). It does
NOT connect to a live Primavera P6 instance and does NOT generate a real
.XER file — that would require Oracle's proprietary XER writer and a
licensed P6 environment, neither of which is available here. This is
clearly labelled everywhere it is shown in the UI and API.
"""
import csv
import io
import xml.etree.ElementTree as ET
from typing import List

from app.models.models import Activity


def build_csv_export(activities: List[Activity]) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow([
        "activity_id", "activity_name", "planned_quantity", "planned_unit",
        "physical_progress_pct", "verified_progress_pct", "status",
    ])
    for a in activities:
        writer.writerow([
            a.activity_id, a.name, a.planned_quantity, a.planned_unit,
            a.physical_progress_pct, a.verified_progress_pct, a.status,
        ])
    return buffer.getvalue()


def build_xml_export(activities: List[Activity]) -> str:
    root = ET.Element("PlanBridgeP6UpdatePackage", attrib={
        "note": "Prototype P6-compatible export representation - not a live Primavera connection",
    })
    for a in activities:
        act_el = ET.SubElement(root, "Activity")
        ET.SubElement(act_el, "ActivityID").text = a.activity_id
        ET.SubElement(act_el, "ActivityName").text = a.name
        ET.SubElement(act_el, "PlannedQuantity").text = str(a.planned_quantity)
        ET.SubElement(act_el, "PlannedUnit").text = a.planned_unit
        ET.SubElement(act_el, "PhysicalProgressPct").text = str(a.physical_progress_pct)
        ET.SubElement(act_el, "VerifiedProgressPct").text = str(a.verified_progress_pct)
        ET.SubElement(act_el, "Status").text = a.status
    return ET.tostring(root, encoding="unicode")
