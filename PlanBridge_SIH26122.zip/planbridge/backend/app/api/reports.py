from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user, require_role
from app.core.config import settings
from app.models.models import User, FieldReport, ReportEntity, Project
from app.schemas.schemas import ReportTextCreate, ReportOut, EntitiesOut
from app.ingestion.parsers import parse_upload
from app.normalization.entities import extract_entities
from app.normalization.units import normalize_unit
from app.services.evidence_service import sha256_of_text, find_duplicate_report
from app.audit.logger import log_event

router = APIRouter(prefix="/reports", tags=["reports"])

ALLOWED_ROLES_UPLOAD = ["FIELD_ENGINEER", "PLANNER", "ADMIN"]


def _store_report(db: Session, project_id: int, raw_text: str, reporter_name: str,
                   source_type: str, original_filename: str, actor: str) -> FieldReport:
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    file_hash = sha256_of_text(raw_text)
    duplicate = find_duplicate_report(db, project_id, file_hash)

    report = FieldReport(
        project_id=project_id,
        reporter_name=reporter_name,
        source_type=source_type,
        original_filename=original_filename,
        raw_text=raw_text,
        sha256_hash=file_hash,
        processing_status="RECEIVED",
        is_duplicate=bool(duplicate),
        duplicate_of_id=duplicate.id if duplicate else None,
    )
    db.add(report)
    db.commit()
    db.refresh(report)

    log_event(db, "REPORT_RECEIVED", actor=actor, report_id=report.id,
              details={"source_type": source_type, "filename": original_filename})
    if duplicate:
        log_event(db, "DUPLICATE_FLAGGED", actor=actor, report_id=report.id,
                  details={"duplicate_of": duplicate.id})
    return report


@router.post("/text", response_model=ReportOut)
def submit_text_report(payload: ReportTextCreate, db: Session = Depends(get_db),
                        user: User = Depends(get_current_user)):
    report = _store_report(db, payload.project_id, payload.raw_text,
                            payload.reporter_name or user.full_name,
                            payload.source_type, "", user.email)
    return report


@router.post("/upload", response_model=ReportOut)
async def upload_report(project_id: int = Form(...), reporter_name: str = Form(""),
                         file: UploadFile = File(...), db: Session = Depends(get_db),
                         user: User = Depends(get_current_user)):
    raw_bytes = await file.read()
    max_bytes = settings.MAX_UPLOAD_MB * 1024 * 1024
    if len(raw_bytes) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File exceeds {settings.MAX_UPLOAD_MB}MB limit")

    text, source_type = parse_upload(file.filename, raw_bytes, file.content_type or "")
    report = _store_report(db, project_id, text, reporter_name or user.full_name,
                            source_type, file.filename, user.email)
    return report


@router.get("", response_model=list[ReportOut])
def list_reports(project_id: int | None = None, db: Session = Depends(get_db),
                  user: User = Depends(get_current_user)):
    q = db.query(FieldReport)
    if project_id:
        q = q.filter(FieldReport.project_id == project_id)
    return q.order_by(FieldReport.created_at.desc()).all()


@router.get("/{report_id}", response_model=ReportOut)
def get_report(report_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    report = db.query(FieldReport).filter(FieldReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


@router.post("/{report_id}/process", response_model=EntitiesOut)
def process_report(report_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    report = db.query(FieldReport).filter(FieldReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    extracted = extract_entities(report.raw_text)
    log_event(db, "ENTITY_EXTRACTED", actor=user.email, report_id=report.id,
              details={"kp": extracted.kp, "activity_type": extracted.activity_type})

    # Determine normalization target: km if activity-scale quantities look large, else metres.
    # We normalize against metres as the canonical planning unit for length by default;
    # true target unit is re-derived per-candidate-activity during matching.
    norm = normalize_unit(extracted.quantity_value, extracted.quantity_unit, "km") \
        if extracted.quantity_unit in ("m", "km", "mm", "cm") else \
        normalize_unit(extracted.quantity_value, extracted.quantity_unit, extracted.quantity_unit or "")

    existing = db.query(ReportEntity).filter(ReportEntity.report_id == report.id).first()
    if existing:
        db.delete(existing)
        db.commit()

    entity_row = ReportEntity(
        report_id=report.id,
        kp=extracted.kp or "",
        line_number=extracted.line_number or "",
        location=extracted.location or "",
        activity_type=extracted.activity_type or "",
        quantity_raw_value=extracted.quantity_value,
        quantity_raw_unit=extracted.quantity_unit or "",
        quantity_normalized_value=norm.normalized_value,
        quantity_normalized_unit=norm.normalized_unit or "",
        conversion_rule=norm.conversion_rule,
        conversion_status=norm.status,
        contractor_mentioned=extracted.contractor or "",
        equipment=extracted.equipment or "",
    )
    db.add(entity_row)
    report.processing_status = "PROCESSED"
    db.commit()
    db.refresh(entity_row)

    log_event(db, "REPORT_PROCESSED", actor=user.email, report_id=report.id)
    return entity_row
