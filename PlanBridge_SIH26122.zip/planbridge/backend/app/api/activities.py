from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import User, Project, Activity
from app.schemas.schemas import ActivityOut

router = APIRouter(tags=["activities"])


@router.get("/projects")
def list_projects(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    projects = db.query(Project).all()
    return [{"id": p.id, "code": p.code, "name": p.name, "description": p.description} for p in projects]


@router.get("/activities", response_model=list[ActivityOut])
def list_activities(project_id: int | None = None, status: str | None = None,
                     db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = db.query(Activity)
    if project_id:
        q = q.filter(Activity.project_id == project_id)
    if status:
        q = q.filter(Activity.status == status)
    return q.order_by(Activity.activity_id).limit(500).all()


@router.get("/activities/{activity_id}")
def get_activity_detail(activity_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    activity = db.query(Activity).filter(Activity.id == activity_id).first()
    if not activity:
        raise HTTPException(status_code=404, detail="Activity not found")
    return {
        "activity": ActivityOut.model_validate(activity),
        "matches": [
            {
                "match_id": m.id, "report_id": m.report_id, "final_confidence": m.final_confidence,
                "decision": m.decision, "planner_decision": m.planner_decision,
                "explanation": m.explanation,
            } for m in activity.matches
        ],
    }
