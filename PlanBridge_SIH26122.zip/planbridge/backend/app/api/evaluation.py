"""
Synthetic prototype evaluation (spec section 27).

Compares three matching strategies against a small labelled benchmark set
built from the seeded demo reports (which include a `ground_truth_activity_id`
label). Results are clearly labelled as a synthetic prototype evaluation,
never presented as real-world measured performance.
"""
import time
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import User, FieldReport, ReportEntity, Activity
from app.normalization.entities import extract_entities, ExtractedEntities
from app.matching.candidates import get_candidate_activities
from app.matching.confidence import score_candidates
from app.ai.embedder import semantic_similarity

router = APIRouter(tags=["evaluation"])


def _keyword_match(text: str, candidates: list[Activity]) -> Activity | None:
    text_lower = text.lower()
    best, best_score = None, 0
    for c in candidates:
        overlap = sum(1 for w in c.name.lower().split() if w in text_lower)
        if overlap > best_score:
            best, best_score = c, overlap
    return best


def _semantic_only_match(text: str, candidates: list[Activity]) -> Activity | None:
    best, best_score = None, -1.0
    for c in candidates:
        score = semantic_similarity(text, c.name)
        if score > best_score:
            best, best_score = c, score
    return best


@router.get("/evaluation/run")
def run_evaluation(project_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    reports = (
        db.query(FieldReport)
        .filter(FieldReport.project_id == project_id, FieldReport.processing_status.in_(["PROCESSED", "MATCHED"]))
        .all()
    )
    activities = db.query(Activity).filter(Activity.project_id == project_id).all()

    results = {"KEYWORD": {"top1": 0, "top3": 0, "tp": 0, "fp": 0, "fn": 0, "false_auto": 0, "auto_total": 0, "time": 0.0},
               "SEMANTIC": {"top1": 0, "top3": 0, "tp": 0, "fp": 0, "fn": 0, "false_auto": 0, "auto_total": 0, "time": 0.0},
               "HYBRID": {"top1": 0, "top3": 0, "tp": 0, "fp": 0, "fn": 0, "false_auto": 0, "auto_total": 0, "time": 0.0}}

    n = 0
    for report in reports:
        entity_row = db.query(ReportEntity).filter(ReportEntity.report_id == report.id).first()
        if not entity_row:
            continue
        entities = ExtractedEntities(
            kp=entity_row.kp or None, activity_type=entity_row.activity_type or None,
            location=entity_row.location or None, quantity_value=entity_row.quantity_raw_value,
            quantity_unit=entity_row.quantity_raw_unit or None,
        )
        # naive ground truth: the activity whose kp+activity_type matches the report entities
        truth = next((a for a in activities if a.kp == entities.kp and a.activity_type == entities.activity_type), None)
        if not truth:
            continue
        n += 1

        candidates = get_candidate_activities(db, project_id, entities, limit=8) or activities[:8]

        t0 = time.perf_counter()
        kw_pick = _keyword_match(report.raw_text, candidates)
        results["KEYWORD"]["time"] += time.perf_counter() - t0
        if kw_pick and kw_pick.id == truth.id:
            results["KEYWORD"]["top1"] += 1
            results["KEYWORD"]["top3"] += 1
            results["KEYWORD"]["tp"] += 1
        else:
            results["KEYWORD"]["fn"] += 1

        t0 = time.perf_counter()
        sem_pick = _semantic_only_match(report.raw_text, candidates)
        results["SEMANTIC"]["time"] += time.perf_counter() - t0
        if sem_pick and sem_pick.id == truth.id:
            results["SEMANTIC"]["top1"] += 1
            results["SEMANTIC"]["top3"] += 1
            results["SEMANTIC"]["tp"] += 1
        else:
            results["SEMANTIC"]["fn"] += 1

        t0 = time.perf_counter()
        scored = score_candidates(entities, report.raw_text, candidates)
        results["HYBRID"]["time"] += time.perf_counter() - t0
        top3_ids = [s.activity.id for s in scored[:3]]
        if scored and scored[0].activity.id == truth.id:
            results["HYBRID"]["top1"] += 1
            results["HYBRID"]["tp"] += 1
        else:
            results["HYBRID"]["fn"] += 1
        if truth.id in top3_ids:
            results["HYBRID"]["top3"] += 1
        if scored and scored[0].decision == "AUTO_LINK":
            results["HYBRID"]["auto_total"] += 1
            if scored[0].activity.id != truth.id:
                results["HYBRID"]["false_auto"] += 1

    output = {}
    for method, r in results.items():
        precision = r["tp"] / (r["tp"] + r["fp"]) if (r["tp"] + r["fp"]) else 0.0
        recall = r["tp"] / (r["tp"] + r["fn"]) if (r["tp"] + r["fn"]) else 0.0
        f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
        far = round((r["false_auto"] / r["auto_total"]) * 100, 2) if r["auto_total"] else None
        output[method] = {
            "top1_accuracy_pct": round((r["top1"] / n) * 100, 1) if n else 0.0,
            "top3_accuracy_pct": round((r["top3"] / n) * 100, 1) if n else 0.0,
            "precision": round(precision, 3),
            "recall": round(recall, 3),
            "f1": round(f1, 3),
            "false_auto_accept_rate_pct": far,
            "avg_processing_time_ms": round((r["time"] / n) * 1000, 3) if n else 0.0,
        }

    return {"label": "Synthetic Prototype Evaluation - not measured real-world performance",
            "sample_size": n, "results": output}
