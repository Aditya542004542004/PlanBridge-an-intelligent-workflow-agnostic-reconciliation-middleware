from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user, require_role
from app.models.models import User, FieldReport, ReportEntity, Activity, ActivityMatch, PlannerReview
from app.schemas.schemas import MatchRunResponse, MatchCandidateOut, ActivityOut, MatchDecisionRequest
from app.matching.candidates import get_candidate_activities
from app.matching.confidence import score_candidates
from app.normalization.entities import ExtractedEntities
from app.ai.embedder import get_backend_name
from app.audit.logger import log_event
from app.services.progress_service import record_progress
from app.services.evidence_service import create_evidence_record

router = APIRouter(tags=["matching"])


def _entities_from_row(row: ReportEntity) -> ExtractedEntities:
    return ExtractedEntities(
        kp=row.kp or None,
        line_number=row.line_number or None,
        location=row.location or None,
        activity_type=row.activity_type or None,
        quantity_value=row.quantity_raw_value,
        quantity_unit=row.quantity_raw_unit or None,
        contractor=row.contractor_mentioned or None,
        equipment=row.equipment or None,
    )


@router.post("/matching/run/{report_id}", response_model=MatchRunResponse)
def run_matching(report_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    report = db.query(FieldReport).filter(FieldReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    entity_row = db.query(ReportEntity).filter(ReportEntity.report_id == report_id).first()
    if not entity_row:
        raise HTTPException(status_code=400, detail="Report has not been processed yet (run /reports/{id}/process first)")

    entities = _entities_from_row(entity_row)
    candidates = get_candidate_activities(db, report.project_id, entities)
    if not candidates:
        log_event(db, "MATCH_PROPOSED", actor=user.email, report_id=report.id, details={"result": "NO_CANDIDATES"})
        return MatchRunResponse(report_id=report_id, candidates=[], backend=get_backend_name())

    scored = score_candidates(entities, report.raw_text, candidates)

    # wipe previous match proposals for this report so re-running is idempotent
    db.query(ActivityMatch).filter(ActivityMatch.report_id == report_id).delete()
    db.commit()

    out = []
    for rank, result in enumerate(scored, start=1):
        match_row = ActivityMatch(
            report_id=report_id,
            activity_id=result.activity.id,
            entity_score=result.entity_score,
            semantic_score=result.semantic_score,
            quantity_score=result.quantity_score,
            final_confidence=result.final_confidence,
            decision=result.decision,
            explanation=result.explanation,
            rank=rank,
        )
        db.add(match_row)
        db.commit()
        db.refresh(match_row)

        # top-ranked AUTO_LINK match applies immediately; others stay informational
        if rank == 1 and result.decision == "AUTO_LINK":
            match_row.planner_decision = "APPROVED"
            db.commit()

        out.append(MatchCandidateOut(
            match_id=match_row.id,
            report_id=report_id,
            activity=ActivityOut.model_validate(result.activity),
            entity_score=result.entity_score,
            semantic_score=result.semantic_score,
            quantity_score=result.quantity_score,
            final_confidence=result.final_confidence,
            decision=result.decision,
            explanation=result.explanation,
            rank=rank,
        ))

    report.processing_status = "MATCHED"
    db.commit()

    log_event(db, "MATCH_PROPOSED", actor=user.email, report_id=report_id,
              details={"top_confidence": out[0].final_confidence if out else None,
                       "decision": out[0].decision if out else None})

    # If top match auto-linked, immediately compute physical progress + evidence
    if out and out[0].decision == "AUTO_LINK":
        activity = db.query(Activity).filter(Activity.id == out[0].activity.id).first()
        qty = entity_row.quantity_normalized_value or entity_row.quantity_raw_value or 0.0
        unit = entity_row.quantity_normalized_unit or entity_row.quantity_raw_unit or activity.planned_unit
        record_progress(db, activity, report_id, qty, unit)
        create_evidence_record(db, report_id, activity.id, qty, report.reporter_name, "PENDING", report.raw_text)
        log_event(db, "MATCH_ACCEPTED", actor="system(auto-link)", report_id=report_id, activity_id=activity.id)
        log_event(db, "PROGRESS_UPDATED", actor="system", report_id=report_id, activity_id=activity.id,
                  details={"physical_progress_pct": activity.physical_progress_pct})

    return MatchRunResponse(report_id=report_id, candidates=out, backend=get_backend_name())


@router.get("/matching/{report_id}", response_model=MatchRunResponse)
def get_matches(report_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.query(ActivityMatch).filter(ActivityMatch.report_id == report_id).order_by(ActivityMatch.rank).all()
    out = [
        MatchCandidateOut(
            match_id=r.id, report_id=r.report_id, activity=ActivityOut.model_validate(r.activity),
            entity_score=r.entity_score, semantic_score=r.semantic_score,
            quantity_score=r.quantity_score, final_confidence=r.final_confidence,
            decision=r.decision, explanation=r.explanation, rank=r.rank,
        ) for r in rows
    ]
    return MatchRunResponse(report_id=report_id, candidates=out, backend=get_backend_name())


@router.get("/review-queue", response_model=list[MatchCandidateOut])
def review_queue(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = (
        db.query(ActivityMatch)
        .filter(ActivityMatch.decision == "PLANNER_REVIEW", ActivityMatch.planner_decision == "PENDING", ActivityMatch.rank == 1)
        .order_by(ActivityMatch.created_at.desc())
        .all()
    )
    return [
        MatchCandidateOut(
            match_id=r.id, report_id=r.report_id, activity=ActivityOut.model_validate(r.activity),
            entity_score=r.entity_score, semantic_score=r.semantic_score,
            quantity_score=r.quantity_score, final_confidence=r.final_confidence,
            decision=r.decision, explanation=r.explanation, rank=r.rank,
        ) for r in rows
    ]


@router.post("/matches/{match_id}/approve")
def approve_match(match_id: int, payload: MatchDecisionRequest, db: Session = Depends(get_db),
                   user: User = Depends(require_role(["PLANNER"]))):
    match = db.query(ActivityMatch).filter(ActivityMatch.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Match not found")

    activity = match.activity
    if payload.reassign_activity_id:
        activity = db.query(Activity).filter(Activity.id == payload.reassign_activity_id).first()
        if not activity:
            raise HTTPException(status_code=404, detail="Reassignment activity not found")
        match.activity_id = activity.id

    match.planner_decision = "APPROVED"
    db.add(PlannerReview(match_id=match.id, reviewer_id=user.id, decision="APPROVE", notes=payload.notes))
    db.commit()

    report = match.report
    entity_row = db.query(ReportEntity).filter(ReportEntity.report_id == report.id).first()
    qty = (entity_row.quantity_normalized_value or entity_row.quantity_raw_value or 0.0) if entity_row else 0.0
    unit = (entity_row.quantity_normalized_unit or entity_row.quantity_raw_unit or activity.planned_unit) if entity_row else activity.planned_unit
    record_progress(db, activity, report.id, qty, unit)
    create_evidence_record(db, report.id, activity.id, qty, report.reporter_name, "PENDING", report.raw_text)

    log_event(db, "MATCH_ACCEPTED", actor=user.email, report_id=report.id, activity_id=activity.id,
              details={"notes": payload.notes})
    log_event(db, "PROGRESS_UPDATED", actor=user.email, report_id=report.id, activity_id=activity.id)
    return {"status": "approved", "activity_id": activity.id}


@router.post("/matches/{match_id}/reject")
def reject_match(match_id: int, payload: MatchDecisionRequest, db: Session = Depends(get_db),
                  user: User = Depends(require_role(["PLANNER"]))):
    match = db.query(ActivityMatch).filter(ActivityMatch.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Match not found")
    match.planner_decision = "REJECTED"
    match.decision = "UNMATCHED"
    db.add(PlannerReview(match_id=match.id, reviewer_id=user.id, decision="REJECT", notes=payload.notes))
    db.commit()
    log_event(db, "MATCH_REJECTED", actor=user.email, report_id=match.report_id, activity_id=match.activity_id,
              details={"notes": payload.notes})
    return {"status": "rejected"}
