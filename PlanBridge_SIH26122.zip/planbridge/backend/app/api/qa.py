from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user, require_role
from app.models.models import User, QARecord, Activity
from app.schemas.schemas import QACreate, QAOut
from app.audit.logger import log_event
from app.services.progress_service import refresh_verified_progress_after_qa

router = APIRouter(prefix="/qa", tags=["qa"])


@router.post("", response_model=QAOut)
def create_qa_record(payload: QACreate, db: Session = Depends(get_db),
                      user: User = Depends(require_role(["QA_ENGINEER"]))):
    activity = db.query(Activity).filter(Activity.id == payload.activity_id).first()
    if not activity:
        raise HTTPException(status_code=404, detail="Activity not found")

    record = QARecord(
        activity_id=payload.activity_id,
        report_id=payload.report_id,
        inspection_type=payload.inspection_type,
        evidence=payload.evidence,
        status=payload.status,
        inspector=payload.inspector or user.full_name,
        comments=payload.comments,
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    log_event(db, "QA_SUBMITTED", actor=user.email, report_id=payload.report_id,
              activity_id=activity.id, details={"inspection_type": payload.inspection_type, "status": payload.status})

    if payload.status == "PASSED":
        refresh_verified_progress_after_qa(db, activity)
        log_event(db, "QA_APPROVED", actor=user.email, activity_id=activity.id,
                  details={"verified_progress_pct": activity.verified_progress_pct})
    elif payload.status == "FAILED":
        log_event(db, "QA_FAILED", actor=user.email, activity_id=activity.id,
                  details={"comments": payload.comments})

    return record


@router.get("", response_model=list[QAOut])
def list_qa(activity_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = db.query(QARecord)
    if activity_id:
        q = q.filter(QARecord.activity_id == activity_id)
    return q.order_by(QARecord.date.desc()).all()
