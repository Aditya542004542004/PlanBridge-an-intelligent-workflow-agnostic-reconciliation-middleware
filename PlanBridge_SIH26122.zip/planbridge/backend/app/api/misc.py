import os
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user, require_role
from app.core.config import BASE_DIR
from app.models.models import (
    User, Activity, ProgressRecord, EvidenceRecord, AuditLog, ExportPackage,
    FieldReport, ActivityMatch, QARecord, Project,
)
from app.schemas.schemas import ExportRequest, DashboardStats
from app.export.exporter import build_csv_export, build_xml_export
from app.audit.logger import log_event

router = APIRouter(tags=["misc"])

EXPORTS_DIR = BASE_DIR / "exports"
EXPORTS_DIR.mkdir(exist_ok=True)


@router.get("/health")
def health():
    return {"status": "ok", "service": "PlanBridge API"}


@router.get("/progress/{activity_id}")
def get_progress(activity_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    activity = db.query(Activity).filter(Activity.id == activity_id).first()
    if not activity:
        raise HTTPException(status_code=404, detail="Activity not found")
    records = db.query(ProgressRecord).filter(ProgressRecord.activity_id == activity_id).order_by(ProgressRecord.created_at).all()
    return {
        "activity_id": activity_id,
        "planned_quantity": activity.planned_quantity,
        "planned_unit": activity.planned_unit,
        "physical_progress_pct": activity.physical_progress_pct,
        "verified_progress_pct": activity.verified_progress_pct,
        "history": [
            {
                "reported_quantity": r.reported_quantity, "reported_unit": r.reported_unit,
                "physical_progress_pct": r.physical_progress_pct, "verified_progress_pct": r.verified_progress_pct,
                "created_at": r.created_at.isoformat(),
            } for r in records
        ],
    }


@router.get("/evidence/{activity_id}")
def get_evidence(activity_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    records = db.query(EvidenceRecord).filter(EvidenceRecord.activity_id == activity_id).order_by(EvidenceRecord.created_at).all()
    return [
        {
            "id": r.id, "report_id": r.report_id, "quantity": r.quantity, "reporter": r.reporter,
            "qa_status": r.qa_status, "sha256_hash": r.sha256_hash, "created_at": r.created_at.isoformat(),
            "note": "SHA-256 fingerprint for tamper detection, not blockchain-grade immutability.",
        } for r in records
    ]


@router.get("/audit")
def get_audit(activity_id: int | None = None, report_id: int | None = None, limit: int = 200,
              db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = db.query(AuditLog)
    if activity_id:
        q = q.filter(AuditLog.activity_id == activity_id)
    if report_id:
        q = q.filter(AuditLog.report_id == report_id)
    rows = q.order_by(AuditLog.timestamp.desc()).limit(limit).all()
    return [
        {
            "id": r.id, "event_type": r.event_type, "actor": r.actor, "report_id": r.report_id,
            "activity_id": r.activity_id, "details": r.details, "timestamp": r.timestamp.isoformat(),
        } for r in rows
    ]


@router.post("/exports")
def create_export(payload: ExportRequest, db: Session = Depends(get_db),
                   user: User = Depends(require_role(["PLANNER"]))):
    activities = db.query(Activity).filter(Activity.id.in_(payload.activity_ids)).all()
    if not activities:
        raise HTTPException(status_code=404, detail="No matching activities found")

    pkg = ExportPackage(
        project_id=payload.project_id, created_by_id=user.id, status="APPROVED",
        activity_ids=payload.activity_ids, format=payload.format.upper(),
    )
    db.add(pkg)
    db.commit()
    db.refresh(pkg)

    if payload.format.upper() == "XML":
        content = build_xml_export(activities)
        ext = "xml"
    else:
        content = build_csv_export(activities)
        ext = "csv"

    file_path = EXPORTS_DIR / f"export_{pkg.id}.{ext}"
    file_path.write_text(content, encoding="utf-8")
    pkg.file_path = str(file_path)
    pkg.status = "GENERATED"
    db.commit()

    log_event(db, "EXPORT_APPROVED", actor=user.email, details={"export_id": pkg.id})
    log_event(db, "EXPORT_GENERATED", actor=user.email, details={"export_id": pkg.id, "format": pkg.format})

    return {"export_id": pkg.id, "format": pkg.format, "content": content,
            "label": "Prototype P6-compatible export representation - not a live Primavera connection"}


@router.get("/exports/{export_id}")
def get_export(export_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    pkg = db.query(ExportPackage).filter(ExportPackage.id == export_id).first()
    if not pkg:
        raise HTTPException(status_code=404, detail="Export not found")
    content = ""
    if pkg.file_path and os.path.exists(pkg.file_path):
        content = open(pkg.file_path, encoding="utf-8").read()
    return {"export_id": pkg.id, "status": pkg.status, "format": pkg.format, "content": content}


@router.get("/dashboard", response_model=DashboardStats)
def dashboard(project_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    activity_q = db.query(Activity)
    report_q = db.query(FieldReport)
    if project_id:
        activity_q = activity_q.filter(Activity.project_id == project_id)
        report_q = report_q.filter(FieldReport.project_id == project_id)

    activities = activity_q.all()
    reports = report_q.all()

    top_matches = db.query(ActivityMatch).filter(ActivityMatch.rank == 1).all()
    auto_linked = sum(1 for m in top_matches if m.decision == "AUTO_LINK")
    planner_review = sum(1 for m in top_matches if m.decision == "PLANNER_REVIEW" and m.planner_decision == "PENDING")
    unmatched = sum(1 for m in top_matches if m.decision == "UNMATCHED")

    qa_pending = db.query(QARecord).filter(QARecord.status == "PENDING").count()
    qa_verified = db.query(QARecord).filter(QARecord.status == "PASSED").count()

    incorrect_auto = db.query(ActivityMatch).filter(ActivityMatch.decision == "AUTO_LINK", ActivityMatch.planner_decision == "REJECTED").count()
    total_auto = sum(1 for m in top_matches if m.decision == "AUTO_LINK")
    false_auto_accept_rate = round((incorrect_auto / total_auto) * 100, 2) if total_auto else None

    reports_by_source: dict = {}
    for r in reports:
        reports_by_source[r.source_type] = reports_by_source.get(r.source_type, 0) + 1

    status_breakdown: dict = {}
    for a in activities:
        status_breakdown[a.status] = status_breakdown.get(a.status, 0) + 1

    avg_physical = round(sum(a.physical_progress_pct for a in activities) / len(activities), 2) if activities else 0.0
    avg_verified = round(sum(a.verified_progress_pct for a in activities) / len(activities), 2) if activities else 0.0

    return DashboardStats(
        total_projects=db.query(Project).count(),
        total_activities=len(activities),
        reports_processed=sum(1 for r in reports if r.processing_status in ("PROCESSED", "MATCHED")),
        auto_linked=auto_linked,
        planner_reviews=planner_review,
        unmatched=unmatched,
        qa_pending=qa_pending,
        qa_verified=qa_verified,
        avg_physical_progress=avg_physical,
        avg_verified_progress=avg_verified,
        false_auto_accept_rate=false_auto_accept_rate,
        reports_by_source=reports_by_source,
        activity_status_breakdown=status_breakdown,
    )
