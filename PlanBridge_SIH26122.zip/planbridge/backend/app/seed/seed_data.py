"""
Deterministic synthetic demo data (spec section 24).

Creates:
  - 5 demo users (one per role)
  - 1 project: "OIL Duliajan 50 KM Pipeline Project"
  - WBS levels + ~300 demo activities (representative of a 50,000-activity
    scale architecture — the indexing/candidate-filtering design in
    app/matching/candidates.py is what actually enables the 50k scale,
    not the row count seeded here for a fast local demo)
  - the 3 "golden demo" activities named explicitly in the spec
  - 20+ field reports covering: high/medium/low confidence, duplicate,
    missing quantity, unknown unit, QA pending/passed/failed

This is 100% synthetic and does NOT represent real OIL confidential data.
"""
import random
from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from app.core.database import SessionLocal, Base, engine
from app.core.security import hash_password
from app.core.config import settings
from app.models.models import (
    Role, User, Project, Contractor, WBSNode, Activity, FieldReport,
)
from app.services.evidence_service import sha256_of_text

random.seed(42)

ROLES = ["ADMIN", "PLANNER", "FIELD_ENGINEER", "QA_ENGINEER", "PROJECT_MANAGER"]

DEMO_USERS = [
    ("admin@planbridge.demo", "Admin User", "ADMIN"),
    ("planner@planbridge.demo", "Priya Planner", "PLANNER"),
    ("qa@planbridge.demo", "Qadir QA", "QA_ENGINEER"),
    ("manager@planbridge.demo", "Meera Manager", "PROJECT_MANAGER"),
    ("field@planbridge.demo", "Farhan Field", "FIELD_ENGINEER"),
]

ACTIVITY_TYPES = ["HDD", "WELDING", "VALVE_INSTALLATION", "TRENCHING", "BACKFILL", "COATING", "HYDROTEST"]
ACTIVITY_NAMES = {
    "HDD": "Horizontal Directional Drilling (HDD) River Crossing",
    "WELDING": "Pipeline Welding",
    "VALVE_INSTALLATION": "Valve Installation",
    "TRENCHING": "Trenching and Excavation",
    "BACKFILL": "Backfilling of Pipeline Trench",
    "COATING": "Pipe Coating and Wrapping",
    "HYDROTEST": "Hydrostatic Pressure Test",
}
LOCATIONS = ["river site", "road crossing", "yard", "camp", "site"]


def _kp(km: int, m: int) -> str:
    return f"{km}+{m:03d}"


def seed(db: Session, reset: bool = False):
    if reset:
        Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

    if db.query(Role).first():
        print("Seed data already present — skipping.")
        return

    # Roles + users
    role_objs = {}
    for r in ROLES:
        role = Role(name=r)
        db.add(role)
        db.flush()
        role_objs[r] = role

    for email, name, role_name in DEMO_USERS:
        db.add(User(
            email=email, full_name=name,
            hashed_password=hash_password(settings.DEMO_PASSWORD),
            role_id=role_objs[role_name].id,
        ))

    # Project
    project = Project(
        code="OIL-DULIAJAN-50KM",
        name="OIL Duliajan 50 KM Pipeline Project",
        description="Synthetic demo pipeline project for the PlanBridge prototype (SIH26122).",
    )
    db.add(project)
    db.flush()

    contractor = Contractor(name="Demo EPC Contractor Pvt Ltd", contact_email="ops@democontractor.example")
    db.add(contractor)
    db.flush()

    wbs_root = WBSNode(project_id=project.id, code="PIP-L5", name="Line 5 Pipeline Works", level=1)
    db.add(wbs_root)
    db.flush()

    # ---- Representative activity set (architecture supports 50,000+; this
    # seeds a smaller, fast-loading demo set of ~300 activities) ----
    activities = []
    start_date = datetime(2026, 1, 1)
    km_cursor = 0
    idx = 3  # start numbering near the golden-demo activities for realism
    for i in range(300):
        km_cursor = 24 + (i // 6)
        m_offset = (i % 6) * 100
        kp = _kp(km_cursor, m_offset)
        activity_type = ACTIVITY_TYPES[i % len(ACTIVITY_TYPES)]
        seq = f"{idx:03d}"
        idx += 1
        activity_id = f"PIP-L5-{km_cursor:03d}-{seq}"
        planned_qty = {"HDD": 500.0, "WELDING": 300.0, "VALVE_INSTALLATION": 2.0,
                       "TRENCHING": 800.0, "BACKFILL": 800.0, "COATING": 600.0,
                       "HYDROTEST": 1000.0}[activity_type]
        planned_unit = "nos" if activity_type == "VALVE_INSTALLATION" else "m"
        activities.append(Activity(
            activity_id=activity_id,
            project_id=project.id,
            wbs_id=wbs_root.id,
            name=f"{ACTIVITY_NAMES[activity_type]} at KP {kp}",
            discipline="PIPELINE",
            activity_type=activity_type,
            kp=kp,
            line_number="5",
            location_tag=LOCATIONS[i % len(LOCATIONS)],
            planned_quantity=planned_qty,
            planned_unit=planned_unit,
            planned_start=start_date + timedelta(days=i),
            planned_finish=start_date + timedelta(days=i + 14),
            status="NOT_STARTED",
        ))

    # ---- Golden demo activities (exact spec section 2) ----
    golden = [
        Activity(activity_id="PIP-L5-024-003", project_id=project.id, wbs_id=wbs_root.id,
                  name="Horizontal Directional Drilling (HDD) River Crossing at KP 24+600",
                  discipline="PIPELINE", activity_type="HDD", kp="24+600", line_number="5",
                  location_tag="river site", planned_quantity=500.0, planned_unit="m",
                  planned_start=start_date, planned_finish=start_date + timedelta(days=20), status="NOT_STARTED"),
        Activity(activity_id="PIP-L5-024-004", project_id=project.id, wbs_id=wbs_root.id,
                  name="Pipeline Welding at KP 24+600",
                  discipline="PIPELINE", activity_type="WELDING", kp="24+600", line_number="5",
                  location_tag="river site", planned_quantity=300.0, planned_unit="m",
                  planned_start=start_date, planned_finish=start_date + timedelta(days=10), status="NOT_STARTED"),
        Activity(activity_id="PIP-L5-025-001", project_id=project.id, wbs_id=wbs_root.id,
                  name="Valve Installation at KP 25+100",
                  discipline="PIPELINE", activity_type="VALVE_INSTALLATION", kp="25+100", line_number="5",
                  location_tag="site", planned_quantity=2.0, planned_unit="nos",
                  planned_start=start_date, planned_finish=start_date + timedelta(days=5), status="NOT_STARTED"),
    ]

    for a in activities + golden:
        db.add(a)
    db.flush()

    # ---- 20+ demo field reports covering required scenarios ----
    demo_reports = [
        # 1-2: golden demo flow (HIGH confidence -> then QA pass report)
        dict(text="150m HDD drilling completed today near KP 24+600 at river site.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="NDT radiography passed for 150m HDD at KP 24+600.",
             reporter="Qadir QA", source="MANUAL"),
        # 3: MEDIUM confidence (partial entity match, weld report near same KP but different activity)
        dict(text="Welding progress update near KP 24+600, approx 80m completed on line 5.",
             reporter="Farhan Field", source="MANUAL"),
        # 4: LOW confidence / vague report
        dict(text="Some work happened near the pipeline yard today, team continued works.",
             reporter="Farhan Field", source="MANUAL"),
        # 5: duplicate of report 1 (exact same text)
        dict(text="150m HDD drilling completed today near KP 24+600 at river site.",
             reporter="Farhan Field", source="MANUAL"),
        # 6: missing quantity
        dict(text="HDD drilling activity ongoing at KP 24+600 river site, quantity to be confirmed.",
             reporter="Farhan Field", source="MANUAL"),
        # 7: unknown/domain-specific unit
        dict(text="Completed 4 spools of valve installation work at KP 25+100 site.",
             reporter="Farhan Field", source="MANUAL"),
        # 8: QA failed scenario
        dict(text="Girth welding of 120m completed at KP 24+700 on line 5.",
             reporter="Farhan Field", source="MANUAL"),
        # 9-20: general spread across activity types / KPs for evaluation + dashboard variety
        dict(text="Trenching completed 250m near KP 24+800 site, excavator deployed.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="Backfilling of 300m trench done at KP 24+800 camp area.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="Coating and wrapping finished for 200m pipe section near KP 24+900.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="Hydrostatic pressure test conducted for 500m section at KP 25+000, result pending.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="Valve installation contractor DemoEPC completed 1 valve unit at KP 25+100.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="HDD rig mobilized at KP 24+600 river crossing, drilling to start tomorrow.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="Welding machine breakdown reported at KP 24+600, work halted for the day.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="Trenching 400m completed near KP 25+000 road crossing.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="NDT radiography failed for weld joint at KP 24+700, repair required.",
             reporter="Qadir QA", source="MANUAL"),
        dict(text="200 kg of coating material consumed at KP 24+900 site today.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="Backfill work resumed at KP 24+900 yard after rain delay.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="5000 m of right-of-way clearance completed across line 5 corridor.",
             reporter="Farhan Field", source="MANUAL"),
        dict(text="Valve installation QA inspection scheduled for KP 25+100 next week.",
             reporter="Meera Manager", source="MANUAL"),
        dict(text="Hydrotest at KP 25+000 passed successfully, pressure held for 24 hours.",
             reporter="Qadir QA", source="MANUAL"),
    ]

    now = datetime.utcnow()
    for i, r in enumerate(demo_reports):
        text = r["text"]
        report_hash = sha256_of_text(text)
        is_dup = (i == 4)  # report #5 (index 4) duplicates report #1 (index 0)
        db.add(FieldReport(
            project_id=project.id,
            contractor_id=contractor.id,
            reporter_name=r["reporter"],
            report_date=now - timedelta(days=len(demo_reports) - i),
            source_type=r["source"],
            original_filename="",
            raw_text=text,
            sha256_hash=report_hash,
            processing_status="RECEIVED",
            is_duplicate=is_dup,
        ))

    db.commit()
    print(f"Seeded project '{project.name}' with {len(activities) + len(golden)} activities and {len(demo_reports)} field reports.")


if __name__ == "__main__":
    db = SessionLocal()
    try:
        seed(db)
    finally:
        db.close()
