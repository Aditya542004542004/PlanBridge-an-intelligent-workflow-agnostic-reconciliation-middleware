"""
Central configuration for PlanBridge backend.
Reads from environment variables / .env file. Never hardcode secrets in code.
"""
import os
from pathlib import Path
from pydantic_settings import BaseSettings

BASE_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    APP_NAME: str = "PlanBridge"
    DATABASE_URL: str = f"sqlite:///{BASE_DIR / 'planbridge.db'}"
    JWT_SECRET_KEY: str = os.environ.get("JWT_SECRET_KEY", "insecure-dev-secret-change-me")
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 480
    CORS_ORIGINS: str = "http://localhost:5173,http://localhost:3000"
    MAX_UPLOAD_MB: int = 15
    SEMANTIC_MODEL_NAME: str = "all-MiniLM-L6-v2"
    DEMO_PASSWORD: str = "PlanBridge@2026"

    # Confidence engine weights (configurable per spec section 11)
    WEIGHT_SEMANTIC: float = 0.45
    WEIGHT_ENTITY: float = 0.35
    WEIGHT_QUANTITY: float = 0.20

    THRESHOLD_AUTO_LINK: float = 85.0
    THRESHOLD_PLANNER_REVIEW: float = 60.0

    class Config:
        env_file = ".env"

    @property
    def cors_origin_list(self):
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


settings = Settings()
