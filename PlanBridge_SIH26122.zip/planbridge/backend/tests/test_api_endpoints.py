"""
End-to-end API tests using FastAPI's TestClient against a temporary SQLite
database. Exercises the golden demo flow described in spec section 2 through
the real HTTP endpoints, not just the underlying service functions.
"""
import os
import tempfile

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client(tmp_path, monkeypatch):
    db_file = tmp_path / "test_planbridge.db"
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{db_file}")
    monkeypatch.setenv("JWT_SECRET_KEY", "test-secret")

    # Import after env vars are set so Settings() picks them up
    from app.main import app
    from app.core.database import SessionLocal
    from app.seed.seed_data import seed

    db = SessionLocal()
    try:
        seed(db)
    finally:
        db.close()

    return TestClient(app)


def _login(client, email, password="PlanBridge@2026"):
    res = client.post("/auth/login", json={"email": email, "password": password})
    assert res.status_code == 200, res.text
    return res.json()["access_token"]


def test_health(client):
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["status"] == "ok"


def test_login_success_and_failure(client):
    token = _login(client, "planner@planbridge.demo")
    assert token

    bad = client.post("/auth/login", json={"email": "planner@planbridge.demo", "password": "wrong"})
    assert bad.status_code == 401


def test_golden_demo_end_to_end(client):
    token = _login(client, "field@planbridge.demo")
    headers = {"Authorization": f"Bearer {token}"}

    projects = client.get("/projects", headers=headers).json()
    project_id = projects[0]["id"]

    # Submit the exact golden-demo field report
    report_res = client.post("/reports/text", headers=headers, json={
        "project_id": project_id,
        "raw_text": "150m HDD drilling completed today near KP 24+600 at river site.",
        "reporter_name": "Farhan Field",
    })
    assert report_res.status_code == 200
    report_id = report_res.json()["id"]

    process_res = client.post(f"/reports/{report_id}/process", headers=headers)
    assert process_res.status_code == 200
    entities = process_res.json()
    assert entities["kp"] == "24+600"
    assert entities["activity_type"] == "HDD"

    match_res = client.post(f"/matching/run/{report_id}", headers=headers)
    assert match_res.status_code == 200
    candidates = match_res.json()["candidates"]
    assert candidates[0]["activity"]["activity_id"] == "PIP-L5-024-003"
    assert candidates[0]["decision"] == "AUTO_LINK"

    activity_id = candidates[0]["activity"]["id"]
    progress = client.get(f"/progress/{activity_id}", headers=headers).json()
    assert progress["physical_progress_pct"] == 30.0
    assert progress["verified_progress_pct"] == 0.0  # QA not passed yet

    # Second report: QA passes
    qa_token = _login(client, "qa@planbridge.demo")
    qa_headers = {"Authorization": f"Bearer {qa_token}"}
    qa_res = client.post("/qa", headers=qa_headers, json={
        "activity_id": activity_id,
        "inspection_type": "NDT Radiography",
        "status": "PASSED",
        "inspector": "Qadir QA",
    })
    assert qa_res.status_code == 200

    progress_after_qa = client.get(f"/progress/{activity_id}", headers=headers).json()
    assert progress_after_qa["physical_progress_pct"] == 30.0
    assert progress_after_qa["verified_progress_pct"] == 30.0

    # Planner approves an export package
    planner_token = _login(client, "planner@planbridge.demo")
    planner_headers = {"Authorization": f"Bearer {planner_token}"}
    export_res = client.post("/exports", headers=planner_headers, json={
        "project_id": project_id, "activity_ids": [activity_id], "format": "CSV",
    })
    assert export_res.status_code == 200
    assert "PIP-L5-024-003" in export_res.json()["content"]


def test_duplicate_report_is_flagged(client):
    token = _login(client, "field@planbridge.demo")
    headers = {"Authorization": f"Bearer {token}"}
    projects = client.get("/projects", headers=headers).json()
    project_id = projects[0]["id"]

    text = "Duplicate check: 100m trenching completed at KP 30+000."
    first = client.post("/reports/text", headers=headers, json={"project_id": project_id, "raw_text": text})
    second = client.post("/reports/text", headers=headers, json={"project_id": project_id, "raw_text": text})
    assert first.json()["is_duplicate"] is False
    assert second.json()["is_duplicate"] is True


def test_field_engineer_cannot_approve_match(client):
    token = _login(client, "field@planbridge.demo")
    headers = {"Authorization": f"Bearer {token}"}
    res = client.post("/matches/1/approve", headers=headers, json={"notes": ""})
    assert res.status_code in (403, 404)  # 403 RBAC, or 404 if match doesn't exist yet — never 200
