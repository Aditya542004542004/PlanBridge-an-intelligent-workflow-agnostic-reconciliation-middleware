from app.matching.confidence import score_candidates
from app.normalization.entities import ExtractedEntities


def test_confidence_thresholds(monkeypatch, golden_activities):
    entities = ExtractedEntities(kp="24+600", activity_type="HDD", location="river site",
                                  quantity_value=150.0, quantity_unit="m")
    scored = score_candidates(entities, "150m HDD drilling completed today near KP 24+600 at river site.", golden_activities)
    top = scored[0]
    assert top.final_confidence > 85
    assert top.decision == "AUTO_LINK"

    weak_entities = ExtractedEntities(kp="24+600", activity_type="WELDING", location="river site",
                                       quantity_value=80.0, quantity_unit="m")
    scored2 = score_candidates(weak_entities, "Welding progress near KP 24+600, 80m completed.", golden_activities)
    top2 = scored2[0]
    assert 60 <= top2.final_confidence <= 100
