"""
Matching engine tests. Uses the real SQLite test database (see conftest.py)
so candidate filtering (stage 1) and confidence scoring (stage 2) are
exercised together, matching how they run in production.
"""
from app.normalization.entities import ExtractedEntities
from app.matching.candidates import get_candidate_activities
from app.matching.confidence import score_candidates


def test_golden_demo_top_candidate(db_session, golden_activities):
    entities = ExtractedEntities(kp="24+600", activity_type="HDD", location="river site",
                                  quantity_value=150.0, quantity_unit="m")
    candidates = get_candidate_activities(db_session, golden_activities[0].project_id, entities)
    assert len(candidates) >= 1

    scored = score_candidates(entities, "150m HDD drilling completed today near KP 24+600 at river site.", candidates)
    assert scored[0].activity.activity_id == "PIP-L5-024-003"
    assert scored[0].decision == "AUTO_LINK"


def test_low_confidence_report_is_unmatched(db_session, golden_activities):
    entities = ExtractedEntities(kp=None, activity_type=None, location=None)
    candidates = get_candidate_activities(db_session, golden_activities[0].project_id, entities)
    scored = score_candidates(entities, "Some work happened near the pipeline yard today.", candidates)
    assert scored[0].decision in ("UNMATCHED", "PLANNER_REVIEW")
