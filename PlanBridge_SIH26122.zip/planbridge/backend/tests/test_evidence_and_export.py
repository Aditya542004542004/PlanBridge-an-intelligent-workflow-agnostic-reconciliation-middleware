from app.services.evidence_service import create_evidence_record
from app.export.exporter import build_csv_export, build_xml_export


def test_evidence_record_has_sha256_fingerprint(db_session, golden_activities):
    activity = golden_activities[0]
    record = create_evidence_record(db_session, report_id=1, activity_id=activity.id, quantity=150.0,
                                     reporter="Farhan Field", qa_status="PENDING", source_text="sample text")
    assert len(record.sha256_hash) == 64  # sha256 hex digest length


def test_csv_export_contains_activity_ids(golden_activities):
    csv_text = build_csv_export(golden_activities)
    assert "PIP-L5-024-003" in csv_text


def test_xml_export_labelled_as_prototype(golden_activities):
    xml_text = build_xml_export(golden_activities)
    assert "Prototype P6-compatible export representation" in xml_text
