from app.services.progress_service import calculate_physical_progress, record_progress, refresh_verified_progress_after_qa
from app.models.models import Activity, QARecord


def test_physical_progress_percentage():
    assert calculate_physical_progress(150, 500) == 30.0


def test_physical_progress_never_exceeds_100():
    assert calculate_physical_progress(600, 500) == 100.0


def test_progress_never_merges_physical_and_verified(db_session, golden_activities):
    activity = golden_activities[0]  # planned 500m HDD
    record_progress(db_session, activity, report_id=None, reported_quantity=150, reported_unit="m")
    assert activity.physical_progress_pct == 30.0
    assert activity.verified_progress_pct == 0.0  # no QA passed yet

    qa = QARecord(activity_id=activity.id, inspection_type="NDT Radiography", status="PASSED", inspector="Qadir QA")
    db_session.add(qa)
    db_session.commit()

    refresh_verified_progress_after_qa(db_session, activity)
    assert activity.verified_progress_pct == 30.0
    assert activity.physical_progress_pct == 30.0
