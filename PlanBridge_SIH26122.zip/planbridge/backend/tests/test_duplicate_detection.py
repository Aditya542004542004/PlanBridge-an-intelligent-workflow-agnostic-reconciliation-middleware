from app.services.evidence_service import sha256_of_text, find_duplicate_report
from app.models.models import FieldReport


def test_identical_text_same_hash():
    a = sha256_of_text("150m HDD drilling completed today near KP 24+600 at river site.")
    b = sha256_of_text("150m HDD drilling completed today near KP 24+600 at river site.")
    assert a == b


def test_different_text_different_hash():
    a = sha256_of_text("150m HDD drilling completed today near KP 24+600 at river site.")
    b = sha256_of_text("160m HDD drilling completed today near KP 24+600 at river site.")
    assert a != b


def test_find_duplicate_report(db_session, sample_project):
    text = "Duplicate detection sample report text."
    h = sha256_of_text(text)
    report = FieldReport(project_id=sample_project.id, reporter_name="Tester", source_type="MANUAL",
                          raw_text=text, sha256_hash=h, processing_status="RECEIVED")
    db_session.add(report)
    db_session.commit()

    dup = find_duplicate_report(db_session, sample_project.id, h)
    assert dup is not None
    assert dup.id == report.id
