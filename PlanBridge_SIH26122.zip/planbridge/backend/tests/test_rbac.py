"""
RBAC tests. Verifies that role-restricted endpoints reject users without
the required role, and allow ADMIN as a superuser (per app.core.security.require_role).
"""
import pytest
from app.core.security import require_role


class FakeRole:
    def __init__(self, name):
        self.name = name


class FakeUser:
    def __init__(self, role_name, is_active=True):
        self.role = FakeRole(role_name)
        self.is_active = is_active


def test_planner_role_is_allowed():
    from app.core.security import require_role
    dep = require_role(["PLANNER"])
    user = FakeUser("PLANNER")
    assert dep(user) is user


def test_field_engineer_is_rejected_from_planner_only_action():
    from fastapi import HTTPException
    from app.core.security import require_role
    dep = require_role(["PLANNER"])
    user = FakeUser("FIELD_ENGINEER")
    with pytest.raises(HTTPException) as exc:
        dep(user)
    assert exc.value.status_code == 403


def test_admin_is_always_allowed():
    from app.core.security import require_role
    dep = require_role(["PLANNER"])
    admin = FakeUser("ADMIN")
    assert dep(admin) is admin
