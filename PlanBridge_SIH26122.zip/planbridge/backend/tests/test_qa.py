from app.services.progress_service import activity_qa_passed
from app.models.models import QARecord


def test_qa_not_passed_by_default(db_session, golden_activities):
    activity = golden_activities[0]
    assert activity_qa_passed(db_session, activity.id) is False


def test_qa_passed_flag_true_after_pass_record(db_session, golden_activities):
    activity = golden_activities[0]
    db_session.add(QARecord(activity_id=activity.id, inspection_type="NDT Radiography", status="PASSED"))
    db_session.commit()
    assert activity_qa_passed(db_session, activity.id) is True


def test_qa_failed_does_not_set_passed(db_session, golden_activities):
    activity = golden_activities[1]
    db_session.add(QARecord(activity_id=activity.id, inspection_type="NDT Radiography", status="FAILED"))
    db_session.commit()
    assert activity_qa_passed(db_session, activity.id) is False
