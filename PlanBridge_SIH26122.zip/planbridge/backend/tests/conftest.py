import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.core.database import Base
from app.models.models import Project, Activity


@pytest.fixture()
def db_session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture()
def sample_project(db_session):
    project = Project(code="OIL-TEST", name="Test Pipeline Project", description="pytest fixture project")
    db_session.add(project)
    db_session.commit()
    db_session.refresh(project)
    return project


@pytest.fixture()
def golden_activities(db_session, sample_project):
    """The 3 golden-demo activities from spec section 2."""
    activities = [
        Activity(activity_id="PIP-L5-024-003", project_id=sample_project.id,
                  name="Horizontal Directional Drilling (HDD) River Crossing at KP 24+600",
                  activity_type="HDD", kp="24+600", location_tag="river site",
                  planned_quantity=500.0, planned_unit="m", status="NOT_STARTED"),
        Activity(activity_id="PIP-L5-024-004", project_id=sample_project.id,
                  name="Pipeline Welding at KP 24+600",
                  activity_type="WELDING", kp="24+600", location_tag="river site",
                  planned_quantity=300.0, planned_unit="m", status="NOT_STARTED"),
        Activity(activity_id="PIP-L5-025-001", project_id=sample_project.id,
                  name="Valve Installation at KP 25+100",
                  activity_type="VALVE_INSTALLATION", kp="25+100", location_tag="site",
                  planned_quantity=2.0, planned_unit="nos", status="NOT_STARTED"),
    ]
    for a in activities:
        db_session.add(a)
    db_session.commit()
    for a in activities:
        db_session.refresh(a)
    return activities
