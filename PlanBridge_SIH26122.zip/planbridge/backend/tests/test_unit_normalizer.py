from app.normalization.units import normalize_unit


def test_metres_to_km():
    r = normalize_unit(150, "m", "km")
    assert abs(r.normalized_value - 0.150) < 1e-9
    assert r.status == "OK"


def test_metres_to_km_large():
    r = normalize_unit(5000, "m", "km")
    assert abs(r.normalized_value - 5.0) < 1e-9


def test_kg_to_tonnes():
    r = normalize_unit(500, "kg", "tonne")
    assert abs(r.normalized_value - 0.5) < 1e-9


def test_mm_to_m():
    r = normalize_unit(1000, "mm", "m")
    assert abs(r.normalized_value - 1.0) < 1e-9


def test_same_unit_identity():
    r = normalize_unit(42, "m", "m")
    assert r.normalized_value == 42
    assert r.status == "SAME_UNIT"


def test_unknown_domain_unit_never_guessed():
    r = normalize_unit(4, "spools", "m")
    assert r.status == "UNKNOWN_UNIT"
    assert r.normalized_value is None


def test_missing_value():
    r = normalize_unit(None, None, "m")
    assert r.status == "MISSING"
