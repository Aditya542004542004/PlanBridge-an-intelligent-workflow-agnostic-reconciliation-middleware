from app.normalization.entities import extract_entities


def test_golden_demo_report():
    e = extract_entities("150m HDD drilling completed today near KP 24+600 at river site.")
    assert e.kp == "24+600"
    assert e.activity_type == "HDD"
    assert e.quantity_value == 150.0
    assert e.quantity_unit == "m"
    assert e.location == "river site"


def test_kp_format_variants():
    assert extract_entities("KP 24+600 works").kp == "24+600"
    assert extract_entities("KP24+600 works").kp == "24+600"
    assert extract_entities("Km 24+600 works").kp == "24+600"
    assert extract_entities("progress near 24+600 today").kp == "24+600"


def test_valve_installation_detection():
    e = extract_entities("Work near Km 25+100 valve installation, 2 nos completed.")
    assert e.kp == "25+100"
    assert e.activity_type == "VALVE_INSTALLATION"


def test_missing_quantity():
    e = extract_entities("HDD drilling activity ongoing at KP 24+600 river site, quantity to be confirmed.")
    assert e.quantity_value is None


def test_no_entities_in_vague_report():
    e = extract_entities("Some work happened near the pipeline yard today, team continued works.")
    assert e.kp is None
    assert e.activity_type is None
